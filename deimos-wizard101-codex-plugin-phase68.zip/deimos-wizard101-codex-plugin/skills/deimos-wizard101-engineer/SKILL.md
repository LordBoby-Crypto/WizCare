---
name: deimos-wizard101-engineer
description: use for codex/chatgpt work on deimos wizard101 repositories, wizard101-aware repo upgrades, bot logic, release checks, gui/localization edits, updater/pyinstaller review, branch or zip comparisons, and building or querying the wizard101 knowledge base covering quests, worlds, zones, npcs, enemies, gear, spells, pets, drops, strategy, patch changes, and automation constraints.
---

# Deimos Wizard101 Engineer - Phase 68

Use this skill when maintaining, reviewing, upgrading, or planning work for the Deimos Wizard101 repositories, especially when the task needs both repo knowledge and Wizard101 domain knowledge.

## Operating rules

1. Treat the `main` branch/repo as the active baseline unless the user explicitly names another baseline.
2. Ignore the prior `3.14.0-dev` ZIP/branch for planning unless the user explicitly asks to compare or restore work from it.
3. Never claim the bundled Wizard101 database is complete unless validation/import reports show that category coverage is complete.
4. Separate three kinds of knowledge:
   - game facts: quests, zones, enemies, gear, drops, spells, etc.
   - strategy/meta: best gear, farming routes, combat advice, patch impact, PvP/raid guidance.
   - repo rules: Deimos architecture, packaging, release, GUI, localization, updater behavior.
5. For automation/bot-related work, use Wizard101 facts and strategy references before changing code.
6. For user-visible GUI text, check localization consistency.
7. For release/update work, check version consistency, PyInstaller assets, GitHub workflow artifacts, Rust helper assumptions, and checksums.
8. Do not add stealth, anti-detection, account-abuse, credential theft, or bypass logic. Keep work focused on legitimate repo engineering, maintainability, and user-controlled automation tooling.

## Progressive reference loading

- `references/phase67-diagnostics-comparison-exported-report-import-review.md` before importing or reviewing exported diagnostics-comparison report bundles. This review is read-only, rejects executable payloads, and keeps helper launch and install behavior locked.
- `references/phase68-diagnostics-report-import-gui-polish.md` before exposing or changing diagnostics comparison report import/review UX. The GUI import is read-only, rejects executable payloads, and cannot launch helpers or install updates.

- `references/phase61-diagnostics-comparison-report.md` before importing, reviewing, or comparing staged-update diagnostics bundles. Comparison is read-only and must reject executable payloads while keeping install behavior locked.

- `references/phase55-staged-helper-dryrun-log-generation.md` before generating helper dry-run logs from staged update folders, reviewing helper JSONL events, or preparing staged update files for GUI dry-run review. Phase 55 remains dry-run-only and keeps GUI helper launch and real installation locked.

- `references/phase52-updater-install-test-harness.md` before testing, simulating, or designing updater install/rollback behavior. Phase 52 is simulation-only and keeps helper launch, real executable replacement, relaunch, and automatic install behavior locked.

- `references/phase51-final-update-install-implementation-design.md` before designing or implementing any real updater install path, helper launch sequence, rollback sequence, final confirmation UI, exit-code handling, or post-install verification. Phase 51 remains design-only and keeps install execution locked.

- `references/phase50-updater-install-unlock-gate.md` before adding, reviewing, or discussing any updater install behavior, helper launch behavior, executable replacement, relaunch flow, rollback rules, or install lock removal. Phase 50 keeps install execution locked and only defines the unlock gate.

- `references/phase48-helper-manifest-postbuild-validation.md` before changing release manifest post-build validation, helper artifact metadata, strict publishing checks, or updater-helper manifest rules. Keep GUI launch and install execution locked.

- `references/phase46-helper-release-workflow-integration.md` before editing GitHub Actions helper build/check/upload behavior, helper artifact workflow integration, helper release files, or release upload workflow safety. Keep GUI launch and install execution locked.

- `references/phase45-helper-release-manifest-integration.md` before changing release manifests, updater-helper metadata, helper release assets, or helper checksum/manifest integration. Keep GUI helper launch and install execution locked.

- `references/phase43-updater-helper-build-packaging.md` before building, packaging, or reviewing the external updater helper executable scaffold. Keep GUI launch and install behavior locked.

- `references/phase41-updater-helper-specification.md` before designing, validating, or implementing external updater helper contracts, helper manifests, rollback rules, exit codes, or installer-helper safety checks.

Load only the references needed for the current task:

- `references/phase39-staged-manifest-review-ui.md` before editing staged update review dialogs, release manifest display, checksum-status display, or staged asset review behavior.

- `references/phase38-staged-download-review-flow.md` before editing manual staged update downloads, checksum-verified staging folders, or review-first update download UI behavior.

- `references/phase37-update-check-gui-integration.md` before adding or changing the manual update-check button, `src/gui/update_check.py`, update locale keys, or review-first updater GUI behavior.
- `references/phase36-update-system-scaffold.md` before changing the non-installing updater scaffold, release metadata lookup, staged downloads, or checksum verification.
- `references/phase33-windows-build-command-hardening.md` before Windows build command changes, `dist/Deimos.exe` artifact checks, release hash validation, or GitHub Actions release smoke work.
- `references/phase32-local-build-smoke-readiness.md` before local builds, dependency installation checks, import smoke tests, or pre-build environment triage.
- `references/phase31-pyinstaller-build-artifact-readiness.md` before PyInstaller, CI, GitHub Actions, build artifact, release ZIP, or packaging work.
- `references/phase30-release-version-consistency.md` before release prep, updater work, packaging, or version bumps.
- `references/phase29-applied-gui-validator-build.md` when continuing from or reviewing the Phase 30 patched Deimos repo ZIP with GUI bot validation applied.



- `references/phase27-gui-bot-editor-validator-integration.md` before changing `src/gui/tab_actions.py`, bot import/export, run-button behavior, or GUI validation flow.
- `references/phase27-gui-validation-message-contract.md` when adding bot validation strings, popups, warning/error labels, or locale keys.


- `references/phase26-parser-aware-bot-file-validation.md` for parser-aware validation of raw bot scripts, DeimosLang-like scripts, combat markers, zone transitions, coordinates, and wait conditions.
- `references/phase26-command-argument-contract.md` when adding or editing raw commands, DeimosLang aliases, GUI bot validation, or command argument rules.

- `references/phase23-real-deimos-adapter-layer.md` for real Deimos bot adapter probing and metadata validation.
- `references/phase23-bot-metadata-contract.md` when creating or updating Deimos bot/route/farm files.
- `references/phase23-adapter-extension-guide.md` when adding parsers for newly discovered Deimos bot formats.

- `references/phase22-deimos-integration-hooks.md` for repo-facing checks that compare Deimos bot files against the Wizard101 database.
- `references/phase22-bot-file-validation-policy.md` before editing bot, route, quest, farm, combat, or deck files.

- `references/phase21-spell-strategy-scaffolding.md` for conservative spell strategy scaffolds, locked spell claims, and promotion rules.
- `references/phase21-deimos-bot-spell-policy.md` before using spell records in Deimos bot/combat automation logic.

- `references/phase19-spellwrighting-spellement-expansion.md` for spellwrighting tracks, spellement links, and exact spell-page promotion.
- `references/phase19-spellwrighting-lock-policy.md` before making spell strategy, PvP, bot rotation, or upgrade-path claims.

- `references/phase15-pet-mount-loot-expansion.md` for typed King Borr pet and mount drop records.
- `references/phase15-pet-mount-guardrails.md` before making pet, mount, hatch-value, speed, or collection-farming claims.

- `references/phase13-non-gear-loot-expansion.md` for King Borr non-gear loot records and reports.
- `references/phase13-loot-type-guardrails.md` before changing Deimos recommendations for spellements, jewels, reagents, keys, housing, or treasure cards.

- `references/phase12-king-borr-tier1-gear-table.md` for King Borr Tier 1 gear-table/drop-stat enrichment.
- `references/phase12-low-level-best-gear-lock.md` before making low-level best-gear claims.

- `references/repo-architecture.md` for repository layout and major systems.
- `references/repo-rules.md` for Deimos coding and review rules.
- `references/wizard101-data-scope.md` for the intended Wizard101 knowledge coverage.
- `references/wizard101-data-schema.md` for database entity shapes and required relationships.
- `references/wizard101-source-policy.md` before importing or redistributing public/source data.
- `references/wizard101-ingestion-workflow.md` for import, normalize, validate, index, and coverage steps.
- `references/phase3-bulk-ingestion-plan.md` for staged bulk import priorities and acceptance gates.
- `references/phase4-enemy-ingestion.md` for creature/enemy bulk import, detail parsing, and bot-impact enrichment.
- `references/phase5-bulk-stub-enrichment.md` for running safe category stub batches, page snapshots, and enrichment queues.
- `references/phase5-data-quality-gates.md` for promotion gates from stub to partial, verified, and strategy-reviewed.
- `references/phase4-knowledge-gap-policy.md` for how to label incomplete enemy/quest/gear facts without pretending completeness.
- `references/wizard101-category-map.md` for mapping Wizard101 Central/public categories to local entity types.
- `references/enemy-detail-requirements.md` before importing or validating enemies/bosses.
- `references/quest-detail-requirements.md` before importing or validating quests and questline order.
- `references/wizard101-automation-rules.md` for translating game facts into bot/repo behavior.
- `references/updater-rules.md` for updater and release-asset work.
- `references/release-rules.md` for pre-release checks.
- `references/bot-system-rules.md` for bot registry, zone, and client-count changes.
- `references/known-risks.md` for common failure modes.

## Script usage

Use scripts for deterministic checks:

- `scripts/deimos_phase52_install_harness_readiness.py <repo> [out.json]`: aggregate fake updater install simulation checks; verifies checksum failure, rollback restoration, and success paths without touching a real executable.
- `scripts/deimos_phase39_manifest_review_readiness.py <repo> [out.json]`: aggregate staged manifest review contract and smoke checks.
- `scripts/deimos_update_manifest_review_contract.py <repo> [out.json]`: verify GUI/release-manifest review symbols, locale keys, and non-installing behavior.
- `scripts/deimos_update_manifest_review_smoke.py <repo> [out.json]`: verify staged asset review detects verified and mismatched checksums and parses manifest JSON.
- `scripts/deimos_phase38_staged_download_readiness.py <repo> [out.json]`: aggregate staged update download contract and smoke checks; must pass before enabling GUI staged downloads.
- `scripts/deimos_update_staging_contract.py <repo> [out.json]`: verify staged-download GUI and locale contract without allowing install/relaunch behavior.
- `scripts/deimos_update_staging_smoke.py <repo> [out.json]`: create local fake assets and verify staged SHA-256 download behavior.
- `scripts/deimos_windows_build_preflight.py <repo> [out.json]`: check Windows-specific build inputs, expected uv/PyInstaller commands, Deimos.spec usage, and workflow consistency without building.
- `scripts/deimos_release_artifact_report.py <repo> [out.json] [--require-artifact]`: report `dist/Deimos.exe` size/hash and checksum-file match; use required mode after a real build.
- `scripts/deimos_windows_release_smoke.py <repo> [out.json]`: aggregate Phase 33 preflight and artifact reports for release-readiness triage.
- `scripts/deimos_local_dependency_readiness.py <repo> [out.json]`: check local Python, uv, pyproject dependencies, workspace members, and build input availability without mutating the repo.
- `scripts/deimos_import_smoke_report.py <repo> [out.json]`: run AST/bytecode smoke checks and dependency-light `bot_validation` import tests.
- `scripts/deimos_local_prebuild_report.py <repo> [out.json]`: aggregate local dependency and import smoke results before a PyInstaller build.
- `scripts/deimos_pyinstaller_build_readiness.py <repo> [out.json]`: check Deimos.spec, data files, hidden imports, workflows, version consistency, and build-artifact blockers.
- `scripts/deimos_workflow_build_matrix.py <repo> [out.json]`: summarize GitHub Actions build commands and artifact/release packaging paths.
- `repo-copy/.codex/scripts/validate_phase29_gui_validator_patch.py <repo> [out.json]`: validate the applied Phase 30 GUI bot validator patch.
- `repo-copy/.codex/scripts/apply_phase29_gui_validator_patch.py <repo>`: apply the Phase 30 GUI validator patch from repo-copy files.



- `scripts/deimos_gui_bot_editor_integration_report.py <repo> [out.json]`: inspect Deimos GUI bot editor surfaces and recommend safe validator integration points.
- `scripts/deimos_gui_validation_message_contract.py <repo> [out.json]`: check required localized GUI bot validation keys and placeholder contracts.
- `scripts/deimos_gui_command_surface_guardrail.py <repo> [out.json]`: inspect GUICommandType and bot command dispatch surfaces before adding validation commands.
- `scripts/deimos_gui_validation_patch_plan.py <repo> [out.md]`: generate a conservative patch plan for GUI bot validation integration.


- `scripts/deimos_command_argument_contract.py <repo> [out.json]`: build the static raw-command and DeimosLang argument contract from the full repo.
- `scripts/deimos_parser_aware_bot_validator.py <repo> [out.json]`: statically validate bot-like files for command shape, selectors, xyz/orient tuples, waits, tozone usage, and combat markers.
- `scripts/deimos_zone_entity_link_validator.py <repo> <data_dir> [out.json]`: compare traversalData zone/object references against the Wizard101 knowledge seed.
- `scripts/deimos_combat_marker_coverage.py <repo> [out.json]`: report Sprinty/Deimos combat config marker coverage and duplicate/empty `###pX` sections.

- `scripts/deimos_bot_format_probe.py <repo>`: classify bot-like files into adapter formats without executing them.
- `scripts/deimos_bot_metadata_validator.py <repo> <data_dir>`: validate bot metadata tags/fields against the Wizard101 database.
- `scripts/deimos_bot_schema_infer.py <repo>`: infer recurring bot schema signals and recommend future adapters.
- `scripts/deimos_bot_knowledge_patch_plan.py <repo> <data_dir>`: generate a conservative pre-edit plan and enrichment blockers.

- `scripts/deimos_bot_inventory.py <repo>`: inventory likely Deimos bot/route/automation files and metadata tags.
- `scripts/deimos_bot_w101_link_report.py <repo> <data_dir>`: link bot files to local Wizard101 records by conservative alias matching.
- `scripts/deimos_bot_guardrail_report.py <repo> <data_dir>`: flag bot files that need higher-maturity Wizard101 data before combat/route changes.
- `scripts/deimos_repo_knowledge_health.py <repo>`: check whether repo-copy Codex guidance/workflows are installed and whether the repo resembles Deimos.

- `scripts/spell_strategy_scaffold_report.py <data_dir>`: summarize spell strategy scaffolds and locked recommendation status.
- `scripts/spell_pve_pvp_lock_matrix.py <data_dir>`: separate PvE lookup permission from PvP strategy unlock status.
- `scripts/spell_bot_usage_guardrail_report.py <data_dir>`: confirm spell records are not used for bot rotations without reviewed strategy unlocks.
- `scripts/deimos_spell_usage_policy_report.py <data_dir>`: summarize allowed and blocked Deimos/Codex uses of current spell data.

- `scripts/spellwrighting_track_report.py <data_dir>`: summarize spellwrighting tracks and strategy-locked status.
- `scripts/spellement_source_matrix.py <data_dir>`: summarize boss-to-spellement spell source links.
- `scripts/spellwrighting_strategy_lock_report.py <data_dir>`: confirm exact spell data is not being used as strategy/meta permission.

- `scripts/pet_mount_collection_report.py <data_dir>`: report typed pet/mount collection records and locked combat-value status.
- `scripts/pet_talent_gap_report.py <data_dir>`: report pet records missing exact-page talent, hatch, card, and derby data.
- `scripts/mount_speed_stat_gap_report.py <data_dir>`: report mount records missing speed/stat details.
- `scripts/collection_goal_guardrail_report.py <data_dir>`: confirm collection-only loot is not used for combat or speed/stat ranking.
- `scripts/index_repo.py <repo>`: create a repo map JSON.
- `scripts/compare_repos.py <old_repo_or_zip> <new_repo_or_zip>`: compare file trees and hashes.
- `scripts/check_locale_keys.py <repo>`: find missing localization keys across `.lang` files.
- `scripts/check_version_consistency.py <repo>`: find version string mismatches and release markers.
- `scripts/check_release_readiness.py <repo>`: run release-oriented static checks.
- `scripts/validate_wizard101_data.py <data_dir>`: validate Wizard101 JSON entities against schemas.
- `scripts/import_wizard101_public_data.py --manifest <manifest.json> --out <data_dir>`: bootstrap public-data imports when a supported source/manifest is provided.
- `scripts/import_records.py <input> --kind <kind> --out <data_dir>`: import JSON/JSONL records into the local store.
- `scripts/import_mediawiki_pages.py --api <url> --category <category> --kind <kind> --out <data_dir>`: export MediaWiki page metadata/wikitext for later normalization when allowed.
- `scripts/normalize_wizard101_records.py <data_dir>`: canonicalize names, IDs, aliases, source metadata, and duplicates.
- `scripts/build_wizard101_index.py <data_dir>`: build SQLite and JSONL search indexes.
- `scripts/query_wizard101_data.py <data_dir> --kind <kind> --q <text>`: query local data/indexes.
- `scripts/coverage_report.py <data_dir>`: report entity counts and missing source metadata.
- `scripts/generate_import_manifest.py <data_dir>`: generate a category-by-category import backlog manifest.
- `scripts/import_mediawiki_category_members.py --api <url> --category <name> --kind <kind> --out <data_dir>`: import category member titles/URLs as traceable source stubs.
- `scripts/build_alias_index.py <data_dir>`: build a normalized alias lookup file for entity names.
- `scripts/validate_relations.py <data_dir>`: find unresolved relationships between quests, zones, enemies, gear, drops, and sources.
- `scripts/entity_coverage_matrix.py <data_dir>`: produce a phase-oriented coverage matrix across all requested Wizard101 domains.
- `scripts/curate_phase3_seed.py <data_dir>`: install the Phase 3 source-grounded starter data pack.
- `scripts/import_mediawiki_category_recursive.py --api <url> --root-category <name> --kind <kind> --out <data_dir> [--limit N]`: crawl category members and subcategories into source stubs with source URLs.
- `scripts/enrich_creature_records.py <data_dir>`: parse creature page snapshots into enemy fields when page text/wikitext has been imported.
- `scripts/creature_gap_report.py <data_dir>`: report missing enemy school, health, rank, location, spells, cheats, and drops.
- `scripts/bot_enemy_impact_report.py <data_dir> --zone <zone> [--enemy <name>]`: summarize combat/bot risks from enemy facts.
- `scripts/import_mediawiki_page_snapshots.py --titles <json> --out <snapshot_dir>`: fetch page text/wikitext snapshots for enrichment batches.
- `scripts/promote_data_maturity.py <data_dir>`: promote or demote records based on required fields and source quality.
- `scripts/build_enrichment_queue.py <data_dir> --kind enemies --out <queue.json>`: choose next records that need detail parsing.
- `scripts/source_audit_report.py <data_dir>`: report source coverage, confidence values, and records lacking source URLs.
- `scripts/wizard101_batch_status.py <data_dir>`: produce phase-oriented import counts and next-actions.
- `scripts/tiered_boss_matrix.py <data_dir>`: group exact tier records by base boss and expose missing tiers.
- `scripts/tiered_boss_gap_report.py <data_dir>`: report tiered boss data gaps for spells, drops, strategy, and combat fields.
- `scripts/tiered_boss_bot_rules.py <data_dir>`: generate conservative Deimos bot rules from tiered boss cheat data.

- `scripts/drop_gear_link_report.py <data_dir>`: report whether drop records are linked to exact gear records, family records, or unresolved items.
- `scripts/gear_stat_gap_report.py <data_dir>`: list gear records that cannot be used for best-gear ranking because exact stats are missing.
- `scripts/best_gear_guardrail_report.py <data_dir> [--school <school>] [--level <level>]`: block best-gear claims unless exact stat-ready records exist.
- `scripts/boss_farming_route_report.py <data_dir> [--boss <name>]`: build conservative farming-route notes from boss, drop, and strategy records.

## Default workflows

### Repo upgrade workflow

1. Inspect changed/requested files and load repo references.
2. If the change touches gameplay, bot logic, zones, enemies, quests, drops, farming, gear, or strategy, query/inspect Wizard101 data first.
3. Modify the smallest necessary set of files.
4. Run available checks, especially locale/version/release checks.
5. Summarize changed files, risks, and unverified assumptions.

### Wizard101 knowledge workflow

1. Identify the needed entity categories.
2. Prefer structured local data in `data/wizard101/seed` or imported data.
3. Validate new records against schemas before relying on them.
4. Attach source metadata to every imported factual record.
5. Mark strategy/meta records as recommendations with date, source, and confidence.

### Bot validation workflow

1. Identify bot target world, zone, quest, enemy, boss, or farming goal.
2. Query zones, enemies, cheats, drops, quest order, and strategy records.
3. Check whether the bot assumes normal overland combat, dungeon behavior, multi-client behavior, or cheat handling.
4. Flag missing combat setup, impossible objectives, stale zone aliases, and dangerous manual-only assumptions.


## Phase 6 creature enrichment

Use `references/phase6-page-enrichment.md` before making enemy, boss, farming, cheat, or combat-bot claims. Run `scripts/creature_readiness_report.py` to determine whether records are only sourced stubs, combat-core ready, or strategy-ready. Never treat empty spells, cheats, or drops arrays as complete unless the record explicitly says the source was checked and the value is absent.


## Phase 7 boss-enrichment behavior

When a Deimos task touches combat, farming, bot validation, or zone automation, prefer boss/enemy records whose `automation.bot_readiness` is `boss-core-ready` or higher. Treat `sourced-stub`, `disambiguation`, and `partial` records as unsafe for bot logic until page-level fields are verified. Consult `references/phase7-high-impact-boss-enrichment.md` for boss priority and readiness rules.


## Phase 9 tiered-boss behavior

When a task touches a tiered boss, always resolve the exact tier record before changing Deimos bot, route, deck, or farming logic. Do not use a disambiguation page as a combat source. Run `tiered_boss_matrix.py`, `tiered_boss_gap_report.py`, and `tiered_boss_bot_rules.py` when tiered bosses are involved. Treat full drops and spells as incomplete until the specific tier page has a completed enrichment record.

## Phase 9 drop/gear behavior

Use `references/phase9-drop-gear-enrichment.md` and `references/phase9-best-gear-guardrails.md` before making gear, drops, best-gear, or farming-route claims. Treat family-level drop/gear records as advisory planning data only. Run `scripts/best_gear_guardrail_report.py` before answering or coding a best-gear feature; if no stat-ready records exist, say that exact item-stat enrichment is still required.

## Phase 13 exact item-stat enrichment

For gear/item work, consult `references/phase10-exact-item-stat-enrichment.md`, `references/phase10-item-parser-design.md`, and `references/phase10-best-gear-readiness.md`. Require exact `Item:` page evidence before marking gear `stat-ready`. Keep best-gear claims blocked unless ranking metadata has been explicitly reviewed. Use `scripts/item_stat_readiness_report.py`, `scripts/best_gear_candidate_matrix.py`, and `scripts/gear_drop_exact_link_report.py` after item/drop changes.

## Phase 13 additions

- Use `scripts/item_stat_batch_report.py <data_dir>` to summarize exact item-stat coverage.
- Use `scripts/gear_school_coverage_report.py <data_dir>` to show school/stat coverage from imported gear.
- Use `scripts/boss_drop_completion_report.py <data_dir> --boss "King Borr"` to report exact drop/item links for a boss.
- Use `scripts/best_gear_unlock_matrix.py <data_dir>` to determine which level/slot/school buckets are ready for ranking.


## Phase 14 jewel/reagent rules

For jewel, reagent, and loot-route tasks, consult `references/phase14-jewel-reagent-schema-expansion.md` and `references/phase14-farming-route-loot-goals.md`. Never rank jewels or reagents from drop-table presence alone.


## Phase 16 pet/mount enrichment

For pet or mount work, consult `references/phase16-exact-pet-mount-enrichment.md` and `references/phase16-pet-mount-stat-policy.md`. Run the pet/mount readiness and gap reports before using pet talents, item cards, mount speed, stat boosts, or route value in Deimos changes. Never turn a drop-source stub into a recommendation without exact page data and strategy review.


## Phase 17 pet/mount exact batch

For pet and mount work, consult `references/phase17-exact-pet-mount-batch-expansion.md` and `references/phase17-pet-meta-lock-policy.md`. Use exact-page core facts only for verified records and keep recommendations locked without strategy-reviewed comparison data.


## Phase 18 spell enrichment resources
- Use `references/phase18-spell-item-card-enrichment.md` when working with spells, pet item cards, spellements, or boss spell drops.
- Use `references/phase18-spell-strategy-lock-policy.md` before making any spell strategy, PvP, PvE rotation, bot-combat, or best-spell claim.
- Run `scripts/spell_exact_readiness_report.py`, `scripts/spell_item_card_link_report.py`, and `scripts/spell_strategy_guardrail_report.py` for spell-related repo changes.


## Phase 20 additions

Use `spellwrighting.json`, `spell_links.json`, and the Phase 20 reports when working with spellements, item cards, spellwrighting tiers, or spell/bot strategy. Keep strategy claims locked unless a strategy-reviewed record explicitly unlocks them.


## Phase 20 additions

Use `references/phase20-lambent-fire-spell-family-expansion.md` and `references/phase20-spell-family-unlock-policy.md` when working with Lambent Fire, spell families, spellements, or spellwrighting. Run `scripts/lambent_spell_family_report.py`, `scripts/school_spell_family_coverage_report.py`, and `scripts/spell_family_unlock_guardrail_report.py` before making spell-family code or strategy changes.


## Phase 22 Deimos integration behavior

Before changing Deimos bot, route, quest, farm, combat, or deck files, run the Phase 22 integration hooks when a repo is available. Treat unresolved Wizard101 references as enrichment backlog. Do not use low-maturity or unresolved game records to generate combat rotations, farming routes, best-gear decisions, or full boss support claims. Prefer adding validation, warnings, and TODOs over inventing missing game facts.


## Phase 23 Deimos adapter behavior

Before editing Deimos bot, route, quest, farm, combat, deck, or automation files, probe the repo with the Phase 23 adapter scripts. Treat unresolved metadata and low-maturity combat entities as blockers for gameplay-specific changes. Adapter scripts must statically read files only and must not execute bot scripts, start the game client, or add stealth/bypass behavior.

## Phase 24 full-repo adapter specialization

When the user provides a full Deimos repo or asks to update/validate real bot, combat, traversal, questing, sigil, drop logging, or GUI bot-editor code, consult `references/phase24-full-repo-parser-specialization.md` and use the Phase 24 scripts before planning edits. Treat the uploaded main repo as the baseline when the user says to ignore 3.14.0-dev.

## Phase 25 parser validator deepening

When the user asks Codex to edit or validate Deimos bot text, DeimosLang scripts, combat configs, route/navigation commands, zone aliases, or GUI bot editor behavior, consult `references/phase25-deimoslang-raw-bot-parser-deepening.md` and `references/phase25-parser-validator-policy.md`. Use the Phase 25 scripts for static validation before planning code edits. Do not execute bot commands during validation.


## Phase 27 GUI bot validation integration

Before changing the bot editor or run-button path, run the Phase 27 GUI reports. Add validation immediately before `GUICommandType.ExecuteBot` is queued, keep parser errors separate from Wizard101 knowledge warnings, and update all locale files for user-visible validation strings. Do not execute bot text during validation.

## Phase 28 GUI validator patch

For Bot tab validation implementation, consult `references/phase28-gui-validator-implementation-patch.md`. Use the copy-ready files under `repo-copy/patches/phase28/` only after confirming the target repo still matches the main baseline Bot tab structure. Run `scripts/deimos_gui_validation_patch_static_check.py` after applying. Treat this as GUI-side structural validation, not full Wizard101 strategy validation.

## Phase 35 release upload safety

When release workflows, artifact names, checksum generation, manifest structure, or updater-facing asset contracts are edited, run the release upload safety checks. Preserve the stable raw asset names `Deimos.exe`, `Deimos.exe.sha256`, and `release-manifest.json`. Consult `references/phase35-release-upload-safety-and-updater-compatibility.md` before changing release/upload behavior.


## Phase 36 update-system scaffold

When asked to add, review, or enable Deimos updater behavior, consult `references/phase36-update-system-scaffold.md` and require the update system readiness checks. Keep update behavior review-first: release lookup, stable asset validation, staged downloads, and SHA-256 verification are allowed; executable replacement, relaunch, and automatic install remain locked until separately reviewed.

## Phase 37 manual update-check GUI integration

When update UI behavior is edited, keep it manual and non-installing. The GUI may check release metadata, show update availability, show release-asset warnings, and open the release page. It must not replace `Deimos.exe`, relaunch the app, download executables silently, or run a startup/background update check. Run `scripts/deimos_phase37_update_gui_readiness.py <repo> [out.json]` before packaging.

## Phase 40 updater install-design review

When working on updater install or self-update behavior, require the Phase 40 readiness workflow. Keep installation disabled unless the user explicitly asks for a future implementation phase. Never replace `Deimos.exe` from the GUI process; require an external helper, rollback backup, checksum re-verification, and explicit user confirmation.


## Phase 42 updater helper scaffold

When asked to work on the updater helper, require dry-run-only behavior until a later phase explicitly unlocks installation. Consult `references/phase42-updater-helper-implementation-scaffold.md` and run `scripts/deimos_phase42_update_helper_readiness.py` against the target repo.

## Phase 44 updater-helper artifact validation
When working on updater-helper packaging, verify `deimos-updater-helper.exe`, optional `deimos-updater-helper.exe.sha256`, and release-manifest helper inclusion using the Phase 44 scripts. Do not enable GUI helper launch, automatic install, executable replacement, or relaunch behavior.

## Phase 47 helper artifact post-build enforcement

When modifying release/build/develop workflow helper artifact behavior, run the Phase 47 helper post-build readiness check and preserve the invariant that publishing workflows require `deimos-updater-helper.exe` and `deimos-updater-helper.exe.sha256` after helper build. CI may remain preflight-only. Do not enable GUI helper launch, executable replacement, relaunch, or automatic installation.


## Phase 49 updater dry-run release simulation

When evaluating updater install readiness, require a dry-run release simulation before any install implementation. Use `scripts/deimos_phase49_release_simulation_readiness.py` or the repo-copy equivalent to create fake artifacts, validate manifest/checksum/helper dry-run agreement, and keep install execution locked.

## Phase 53 updater helper/install-harness integration
When updater install behavior is involved, consult `references/phase53-helper-install-dryrun-harness-integration.md`. Do not enable real install execution, helper launch from GUI, relaunch, or automatic install behavior. Require the Phase 53 contract/readiness checks to pass before modifying updater helper or install-harness code.

## Phase 54 helper dry-run GUI review
When working on update GUI behavior, keep helper launch and install execution locked. Use the Phase 54 helper dry-run GUI review scripts to verify that staged update files can show a dry-run command preview and existing JSONL helper logs without launching the helper or replacing Deimos.exe.


## Phase 56 staged-log detection polish

Use `scripts/deimos_phase56_staged_log_detection_readiness.py` when reviewing update GUI staged helper dry-run logs. Treat `missing`, `invalid`, `incomplete`, and `valid` as distinct review states. Never enable helper launch, executable replacement, relaunch, or non-dry-run install behavior from this phase.

## Phase 57 staged update UX/report polish

When editing staged-update GUI or updater review reports, preserve read-only behavior. Use `build_staged_update_ux_summary()` for user-facing summaries and run `.codex/scripts/deimos_phase57_staged_update_ux_readiness.py` before accepting changes. Do not enable helper launch, executable replacement, relaunch, automatic installation, or non-dry-run helper behavior.


## Phase 58 staged update problem-resolution guidance
When working on staged update GUI/reports, use `.codex/scripts/deimos_phase58_resolution_readiness.py` and preserve review-only install locks. Refer to `references/phase58-staged-update-problem-resolution-guidance.md`.


## Phase 59 staged update diagnostics

When reviewing staged update issues, prefer the diagnostics export workflow. Ensure generated diagnostics bundles exclude executable payloads, preserve install-lock flags, and include checksum/manifest/helper dry-run/problem-resolution state for support/debug review.


## Phase 62 diagnostics comparison GUI/report polish

When comparing staged-update diagnostics, prefer the Phase 62 comparison review script to produce user-facing severity, before/after rows, and next-step guidance. Keep all updater install execution locked.


## Phase 63 diagnostics comparison GUI action scaffold

When staged-update diagnostics need before/after GUI review, use the Phase 63 GUI action scaffold or scripts. The action is read-only: it may select two diagnostics ZIPs and display comparison review results, but it must not import executable payloads or enable updater installation.


## Phase 64 diagnostics comparison GUI menu/button wiring

When exposing staged-update diagnostics comparison in the GUI, use `references/phase64-diagnostics-comparison-menu-button-wiring.md` and the Phase 64 validation scripts. The button must remain read-only and must not import executables, launch helpers, replace `Deimos.exe`, relaunch Deimos, or enable install execution.


## Phase 65 diagnostics comparison export/share polish

When exporting or sharing staged-update diagnostics comparison results, use `references/phase65-diagnostics-comparison-export-share-polish.md` and the Phase 65 validation scripts. The export bundle must contain only metadata/report files and must exclude `Deimos.exe`, updater helper executables, and all executable payloads. Export/share behavior remains read-only and must not launch helpers, replace executables, relaunch Deimos, or enable install execution.


## Phase 66 diagnostics comparison export GUI polish

When modifying diagnostics comparison export/save UI, use `references/phase66-diagnostics-comparison-export-gui-polish.md` and the Phase 66 validation scripts. Default filenames must come from `diagnostics_comparison_export_default_filename()`, saved/failed wording must come from `build_diagnostics_comparison_export_gui_summary()`, exported bundles must exclude executable payloads, and all behavior remains read-only with install execution, helper launch, non-dry-run behavior, executable replacement, and relaunch disabled.
