# Strategy and meta data requirements

Strategy records are recommendations, not raw facts. Keep them dated and confidence-rated.

Every strategy/meta record should include:

- target: level range, school, activity, boss, zone, event, raid, PvP mode, or farming goal
- recommendation summary
- required assumptions: membership, crowns, team size, school, level, gear availability, patch date
- alternatives and fallback route
- source type: official, wiki-derived, user-provided, manual-curated, community-guide
- confidence: low, medium, high
- last reviewed date
- Deimos impact: what bot/UI/validation behavior this strategy should influence

Do not hard-code meta choices into Deimos without exposing assumptions and a way to update them.
