# Phase 22 - Deimos integration hooks

Phase 22 adds repo-facing checks that let Codex inspect actual Deimos bot/code files and compare them against the local Wizard101 knowledge database before proposing gameplay-aware changes.

## Goals

- Inventory Deimos bot, route, script, and automation files without assuming one fixed folder layout.
- Extract likely Wizard101 references from filenames and file text: zones, bosses, enemies, spells, drops, gear, schools, skeleton-key terms, and tier markers.
- Link those references to the local Wizard101 database when possible.
- Flag unresolved or low-maturity references instead of inventing missing facts.
- Produce Codex-readable JSON reports that can be attached to implementation plans and PR summaries.

## Required behavior before Deimos bot changes

Before editing a bot or automation workflow, run:

```bash
python scripts/deimos_bot_inventory.py <repo> --out bot-inventory.json
python scripts/deimos_bot_w101_link_report.py <repo> <data_dir> --out bot-w101-link-report.json
python scripts/deimos_bot_guardrail_report.py <repo> <data_dir> --out bot-guardrail-report.json
```

If a bot references a zone, boss, enemy, or spell that is not found in the Wizard101 database, Codex must mark the change as needing knowledge enrichment before making gameplay-specific claims.

## Maturity rules

- `sourced-stub`: okay for lookup and TODO notes only.
- `partial`: okay for planning with caveats; not enough for automated combat logic.
- `combat-core-ready`: okay for basic enemy/boss awareness, but still not full strategy.
- `strategy-reviewed`: required before Codex recommends farming routes, deck rotations, or best-build decisions.

## Integration with Deimos repo work

Use these hooks alongside existing repo checks:

- `check_locale_keys.py` for GUI/user-facing text.
- `check_version_consistency.py` for release/version edits.
- `check_release_readiness.py` for packaging/release work.
- `deimos_repo_knowledge_health.py` to verify repo-copy guidance and Codex workflow files are installed.
