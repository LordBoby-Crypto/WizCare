# Phase 11 - Item Stat Batch Expansion

Use this reference when importing exact item pages after Phase 10.

## Goal

Expand exact item-stat coverage in small, source-verifiable batches. Prefer complete source-grounded records over broad but weak item stubs.

## Batch rule

A batch may promote an item to `stat-ready` only when an exact item page confirms:

- item name and level requirement
- item type
- numeric bonuses or explicit absence of numeric combat stats
- item cards, if listed
- trade/auction flags, if listed
- at least one source/drop/card-pack link
- source URL and retrieval date

## Best-gear rule

`stat-ready` does not mean best-in-slot. Keep `best_gear_status` at `candidate-needs-comparison` or `blocked` until level/school comparison coverage is broad enough.

## Deimos use

Codex may use these records for exact item lookup, drop display, and farming-route context. Codex must not auto-generate best-gear advice from isolated records.
