# Wizard101 automation rules for repo work

Codex must translate game facts into engineering constraints:

- Dungeons, gauntlets, raids, cheating bosses, solo-instance areas, and multi-stage fights are high-risk for generic bot behavior.
- Enemy spell/cheat records should influence combat setup and validation warnings.
- Quest objectives should be classified: talk, explore, defeat, collect, interact, craft, fish, garden, dungeon, badge, training.
- Zone aliases must be normalized before matching bot registry entries.
- Best-gear/farming recommendations are strategy records, not immutable facts.
- Patch-change records should invalidate stale strategy or route records.
