# Creature Parser Design

Use this guide when improving `enrich_creature_records.py`.

## Input forms

The parser accepts records that contain any of:

- `raw_text`
- `wikitext`
- `html_text`
- `snapshot.text`
- `snapshot.wikitext`

## Target fields

The parser should extract conservative fields only when patterns are clear:

- rank: `Rank 10 Boss`, `Rank 3 Elite`, etc.
- health: `Health 8,000`
- school: `School Death`, image alt/title markers, or category markers like `Death Creatures`.
- location: world/zone link strings near a `Location` heading.
- quest appearances: lines after `Quest Appearances`.
- spell notes: lines after `Spell Notes` or image-title spell listings.
- drops: lines after `Drops` grouped by item type.
- cheats: headings or sections that include `Cheat`, `Interrupt`, `Casting Cheat`, or similar.

## Conservative extraction

Do not infer a school from a spell name. Do not infer a cheat from a strategy guide unless it is marked strategy-source. If parsing fails, leave the field empty and let the gap report expose it.
