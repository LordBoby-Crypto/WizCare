# Phase 3 bulk ingestion plan

Phase 3 moves from framework-only ingestion to category-scale ingestion. It must still avoid pretending the Wizard101 database is complete.

## Priority order

1. Source/category map: prove which public source pages cover each requested domain.
2. Core game taxonomy: schools, worlds, zones, locations, instance rules, level/progression brackets.
3. Entity stubs: import page-title records for quests, creatures, items/gear, spells, NPCs, pets, mounts, jewels, reagents, badges, housing, fishing, gardening, monstrology, raids, PvP, packs, bundles, gauntlets, and skeleton-key bosses.
4. Detail extraction: gradually enrich stubs with structured fields, source URLs, last-checked date, confidence, and unresolved fields.
5. Deimos impact layer: convert game facts into bot, farming, questing, UI, and release validation rules.

## Acceptance gates

- Every factual record must contain `sources` with at least source name, kind, URL, and retrieval date.
- Imported category/member stubs are allowed, but must be marked `detail_status: stub`.
- Do not use stubs as if they contain exact health/spell/drop/cheat details.
- Enemy/boss records are not considered detailed until school, rank/health when available, locations, spells, cheats, drops, and automation notes are populated or explicitly marked unknown.
- Quest records are not considered detailed until giver, world/zone, objectives, prereqs/next quests, rewards, and automation notes are populated or explicitly marked unknown.

## Phase 3 deliverables

- import manifests for every major Wizard101 category the user listed.
- scripts for category member import, aliases, relationship validation, and coverage matrix generation.
- starter seed records for core schools, category coverage, patch/update anchors, and import backlog.
- repo-copy workflow docs telling Codex how to expand the database safely.
