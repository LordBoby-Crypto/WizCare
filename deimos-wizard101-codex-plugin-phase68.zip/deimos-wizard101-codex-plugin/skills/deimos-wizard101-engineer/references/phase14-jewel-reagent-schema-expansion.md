# Phase 14 Jewel/Reagent Schema Expansion

Use this reference when Codex works with King Borr Tier 1 non-gear loot, jewels, reagents, or route recommendations.

## Rules
- Treat jewel records as typed loot records, not gear records.
- Do not recommend a jewel as best-in-slot until exact jewel page, socket shape, equip rules, and comparison context are imported.
- Treat reagent records as crafting-resource records. Do not prioritize a reagent farm until crafting-use demand and route efficiency data are known.
- A visible drop table row confirms source presence only; it does not confirm drop rate.
- Participation Trophy remains a guardrail for out-of-range King Borr Tier 1 farming.

## Phase 14 scope
Phase 14 imports the visible King Borr Tier 1 jewel rows and reagent rows into typed collections. These records are source-grounded but still incomplete for strategy/ranking.
