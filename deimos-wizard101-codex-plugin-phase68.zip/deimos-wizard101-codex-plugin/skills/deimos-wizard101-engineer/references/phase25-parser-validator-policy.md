# Phase 25 parser validator policy

Use parser validators before Codex edits bot scripts, command aliases, DeimosLang syntax, combat configs, route files, or GUI bot editor code.

## Required validation behavior

- Validate statically first. Do not run bot commands.
- Report unknown actions as warnings unless they clearly violate known parser grammar.
- Treat `###pX` combat sections as 1-based player markers.
- Link zone strings to Deimos traversal aliases, then to Wizard101 records when available.
- Keep best-route, best-rotation, and boss-full-support claims locked unless strategy data explicitly unlocks them.

## High-review areas

- command parser aliases
- DeimosLang tokenizer/parser/IR/VM changes
- combat config parsing
- teleport/pathing/navigation commands
- questing/sigil/drop logger integrations
- GUI bot import/export/run/kill behavior
