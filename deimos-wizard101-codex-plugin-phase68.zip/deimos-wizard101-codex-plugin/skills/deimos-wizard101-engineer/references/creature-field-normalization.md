# Creature Field Normalization

Normalize enemy records so Codex can query them consistently.

- `school`: use canonical school names: Balance, Death, Fire, Ice, Life, Myth, Storm, Shadow, Sun, Moon, Star, Mixed, Unknown.
- `enemy_type`: use `mob`, `boss`, `elite`, `minion`, `cheating-boss`, `skeleton-key-boss`, `raid-boss`, or `unknown`.
- `rank`: store an integer when possible; preserve rank labels in `rank_label` when the wiki uses tiers, challenge labels, or event-specific variants.
- `health`: integer only; put multiple/tiered health values in `variants`.
- `locations`: exact rooms/sublocations; keep `world` and `zone` as separate top-level fields.
- `spells_used`: list objects with at least `name` and `school` when known.
- `cheats`: list trigger/effect/counter_strategy objects; never summarize cheats as plain prose only.
- `drops`: use drop objects only after source verification; category-level mention is not enough for complete drop data.
- `automation`: include dungeon/instance/team/multi-client/farming/pathing risk notes.
