# Phase 10 Item Parser Design

The item parser should extract only source-visible fields.

## Extractable fields

- item name
- item type icon/category
- level requirement
- bonus lines
- item cards
- trade flags
- drop sources
- vendor sell price
- card pack source
- categories
- source oldid/permalink when available

## Stat normalization examples

- `+3 Global Damage` -> `stats.global_damage_percent = 3`
- `+1 Pip at start of battle` -> `stats.starting_pips = 1`
- `Level Required: 20+` -> `level_requirement = 20`

## Maturity promotion

- `exact-page-stub`: page source exists but no fields parsed.
- `no-stats-listed`: page parsed; no numeric bonuses listed.
- `stat-ready`: numeric stat fields verified from exact page.
- `best-gear-reviewed`: ranking/comparison metadata exists.

## Guardrail

Never infer item stats from item name, pack family, school, or level.
