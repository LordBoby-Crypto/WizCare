# Phase 21 Deimos bot spell policy

Use this reference before changing Deimos bot code that touches spells, item cards, combat ordering, boss farming, or spellwrighting routes.

## Safe Codex behavior

Codex may:

- validate spell names used by bot data or UI.
- link spells to pet item cards, boss drops, or spellement sources.
- show missing-field warnings.
- refuse or defer combat automation when cheat/build/deck context is missing.

## Unsafe or locked behavior

Codex must not:

- infer a cast order from spell damage or pip cost alone.
- use No PvP spells in PvP workflows.
- assume an item card exists in the player's deck.
- choose a spellwrighting branch without exact tier effect records.
- suggest boss automation when cheat handling is unknown.

## Required bot-review inputs

Before creating or changing spell automation logic, require or verify:

1. player school, level, deck, and available spells/cards.
2. enemy school, health, resist/boost assumptions, spells, and cheats.
3. PvE/PvP/raid/farming context.
4. source-grounded strategy record that explicitly unlocks the recommendation.
