# Phase 14 Farming Route Loot Goals

Codex must separate farming goals by loot type:

- Gear/stat goals require exact item stats and comparison buckets.
- Jewel goals require socket/stat/equip verification.
- Reagent goals require crafting-use demand and route efficiency.
- Spellement goals require quantity variants, spell relevance, and drop-source comparison.
- Housing/pet/mount/key goals are collection or utility goals, not combat-stat goals.

When updating Deimos, ask which loot goal the user wants before changing bot recommendation logic. If no goal is supplied, produce a neutral loot report instead of a ranked route.
