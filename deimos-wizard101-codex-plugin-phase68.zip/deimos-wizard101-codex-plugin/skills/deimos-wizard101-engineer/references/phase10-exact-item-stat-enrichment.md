# Phase 10: Exact Item Stat Enrichment

Phase 10 moves from drop-family knowledge to exact item-page knowledge.

## Goal

Create item records that are safe for Codex to use in Deimos features without inventing gear stats.

## Rules

1. Do not mark a gear record `stat-ready` from a boss drop table alone.
2. Require an exact `Item:` page source for every exact stat profile.
3. Preserve item pages that list no numeric bonuses as `no-stats-listed` instead of guessing hidden stats.
4. Keep `best_gear_status = blocked` until ranking/comparison data exists.
5. Link drops to exact gear records only when both source-side and item-side evidence exist.

## Phase 10 seed examples

- `Allfather's Gungnir (Level 20+)` is stat-ready because its item page lists numeric bonuses and item cards.
- `Conjurer's Timeless Tunic` is exact-page verified but not stat-ready because its item page lists trade restrictions but no numeric combat bonuses.

## Deimos use

Codex may use Phase 10 data to build drop/gear lookup UI, farming-route details, and bot target context. It must not use the records to claim best gear unless a later best-gear ranking phase approves them.
