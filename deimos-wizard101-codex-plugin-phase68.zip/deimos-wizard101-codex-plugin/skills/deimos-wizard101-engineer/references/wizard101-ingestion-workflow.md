# Wizard101 Ingestion Workflow

Use this workflow when adding real Wizard101 data.

## Pipeline

1. **Acquire**: collect user JSON/JSONL, repo-derived records, or permitted public source exports.
2. **Stage**: write raw/source data under `data/wizard101/imports/raw/<source>/`.
3. **Normalize**: convert names, aliases, IDs, schools, world/zone relationships, sources, and dates using `normalize_wizard101_records.py`.
4. **Validate**: run `validate_wizard101_data.py data/wizard101` and fix schema failures.
5. **Index**: run `build_wizard101_index.py data/wizard101` to update SQLite and search JSONL.
6. **Coverage**: run `coverage_report.py data/wizard101` and record missing categories or weak-source areas.
7. **Use in repo work**: query the index before editing Deimos code that touches game logic.

## Completion standard

A category is not complete until it has:

- schema-valid records
- stable IDs
- source metadata
- alias handling
- relationship links to related worlds/zones/NPCs/enemies/items when applicable
- coverage notes explaining known gaps

## Strategy/meta records

Strategy records must include `strategy_type`, `applies_to`, `recommendation`, `confidence`, `effective_date`, and sources. Treat them as dated recommendations, not permanent facts.
