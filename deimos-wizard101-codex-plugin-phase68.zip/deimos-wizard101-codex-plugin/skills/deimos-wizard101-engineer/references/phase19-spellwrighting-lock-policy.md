# Phase 19 Spellwrighting Lock Policy

Use these rules before making spell strategy claims.

1. A spell page can verify school, pip costs, accuracy, type, effect, PvP status, acquisition notes, and visible spellwrighting thresholds.
2. A boss drop table can verify a spellement source relationship only. It does not verify the spell's exact behavior.
3. `spellwrighting_tiers` record visible thresholds, not the value of each path.
4. Keep bot rotation, PvP meta, spell choice, and upgrade-path recommendations locked unless `data_quality.strategy_reviewed` is true.
5. When a page says spellements cannot be used to learn a spell, preserve that exception instead of generalizing from other spellwrighting pages.
