# Phase 18 Spell Strategy Lock Policy

Spell facts and spell strategy are separate. Exact page facts can support lookup, validation, and UI display. Strategy claims require a dedicated strategy-reviewed record.

Locked claims until strategy-reviewed:
- best spell for a school or level
- PvP meta usefulness
- PvE rotation priority
- bot combat plan
- farming value beyond source/drop presence
- spellwrighting tier recommendation

When working on Deimos automation, prefer conservative labels: `lookup-ready`, `link-only`, `drop-linked-only`, or `strategy-reviewed`.
