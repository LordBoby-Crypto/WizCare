# Phase 9 - Drop and Gear Enrichment

Phase 9 links high-impact boss records to drop families, gear families, spellements, and conservative farming-route metadata.

## Rules

- Treat a `gear-family` or `drop-family` record as useful for planning, not for exact best-gear rankings.
- Never rank an item as best gear unless the exact item page has been imported, stats are present, level/school restrictions are known, and a strategy record marks it as reviewed.
- Keep drop quantity, drop rate, and report-count data separate from item identity. A listed drop is not a guaranteed drop.
- For tiered bosses, always check tier, level range, key requirements, and out-of-range drop behavior before making bot or farming recommendations.
- For Lambent Fire, treat cheat-aware combat as required before recommending bot automation.
- For King Borr, do not transfer Tier 1 no-cheat behavior to higher tiers.

## Required checks

Run:

```bash
scripts/drop_gear_link_report.py data/wizard101
scripts/gear_stat_gap_report.py data/wizard101
scripts/best_gear_guardrail_report.py data/wizard101 --school Storm --level 60
scripts/boss_farming_route_report.py data/wizard101 --boss "King Borr"
```

## Promotion gates

- `family-linked`: source page lists family/drop category; not exact item stats.
- `item-linked`: exact item page has source URL and acquisition link.
- `stat-ready`: exact stats, school, level, sockets, item cards, and source are imported.
- `strategy-reviewed`: item has been reviewed for actual meta/farming value.
