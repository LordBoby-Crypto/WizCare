# Phase 4 Enemy and Creature Ingestion

Phase 4 starts converting the broad Wizard101 data framework into a practical enemy/boss knowledge layer for Deimos bot work.

## Goal

Build enough repeatable machinery that Codex can ingest, normalize, validate, query, and report on enemy records without confusing partial stubs with complete game facts.

## Priority fields for every enemy

1. `name`, aliases, source URL, source revision when available.
2. `enemy_type` and `classification`: mob, boss, elite, skeleton key boss, cheating boss, dungeon/instance boss, event creature, retired creature.
3. `school`, `health`, `rank`, starting pips, stunnable/beguilable when present.
4. `world`, `zone`, exact locations, quest appearances.
5. `spells_used`: names, school, role when known, and whether the spell is natural attack, trained spell, item card, cheat cast, or unknown.
6. `cheats`: trigger, effect, counter-strategy, and automation implications.
7. `drops`: item name, category, source confidence, badge/key/quest requirements, and farming value.
8. `automation`: dungeon flag, sigil/instance flag, multi-client notes, cheat-handling notes, flee/retry risk, farming suitability.

## Import stages

### Stage A: category stubs

Use `import_mediawiki_category_recursive.py` to import page titles and source URLs from Wizard101 Central categories. Treat these records as stubs only.

Recommended first roots:

- `Creatures`
- `Boss`
- `Skeleton Key Bosses`
- `Spellement-Dropping Creatures`
- `Creatures by School`
- `Creatures by World`

### Stage B: page snapshots

Use `import_mediawiki_pages.py` or your own exported page dump to collect page text/wikitext for specific creatures. Store raw snapshots outside the final small skill if they become large.

### Stage C: parser enrichment

Run `enrich_creature_records.py` to derive school, health, rank, location, quest appearances, spell notes, drops, and cheat markers from imported page text.

### Stage D: gap reports

Run `creature_gap_report.py`. A creature is not detail-complete until these are filled or explicitly marked unavailable:

- school
- health or health note
- rank
- exact location
- spells used
- cheats/no-cheats marker
- drops/no-drops marker
- source URL

## Bot impact rules

For Deimos automation work:

- Missing school means do not make school-specific deck assumptions.
- Missing cheat data means mark boss automation as unverified.
- Dungeon/instance/sigil enemies require dungeon-safe routing assumptions.
- Skeleton key bosses require key-availability checks and must not be treated as normal farming routes.
- Event or retired creatures must be excluded from default bot recommendations unless the user asks for that event/history.
