# Phase 12 - King Borr Tier 1 gear-table pass

Purpose: convert the visible King Borr Tier 1 gear drop table into structured drop records, then enrich exact item pages in safe batches.

Rules:
- Treat drop-table records as proof that an item appears on that drop table, not as proof of exact stats.
- Only mark `stat_profile_status` as `stat-ready` after an exact item page has been inspected.
- Keep `best_gear_status` blocked until comparison buckets have enough stat-ready items.
- Preserve tier and level-gate warnings for all King Borr records.

Current exact Phase 12 additions:
- Odin's Helm (Level 20+)
- Odin's Boots (Level 20+)

Reports to run:
```bash
python scripts/king_borr_tier1_gear_table_report.py data/wizard101 --out phase12-king-borr-table-report.json
python scripts/gear_comparison_bucket_report.py data/wizard101 --out phase12-gear-comparison-bucket-report.json
python scripts/king_borr_exact_stat_queue.py data/wizard101 --out phase12-king-borr-exact-stat-queue.json
```
