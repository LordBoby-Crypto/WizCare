# Phase 6 Page Enrichment

Phase 6 begins page-level enrichment for high-impact creature records. Use this workflow whenever Codex needs enemy facts for bot logic, strategy, or zone-risk review.

## Required order
1. Start from `data/wizard101/sources/phase6_page_enrichment_manifest.json` or `scripts/creature_priority_queue.py`.
2. Fetch or paste one creature page at a time.
3. Extract core combat fields first: school, rank, health, classification, world, zone, exact location, battle statistics, allies/minions.
4. Extract detail tracks separately: spells used, cheats, drops, quest appearances, badges, second-chance chests, monstrology notes.
5. Keep missing detail explicit. Empty arrays mean `checked and absent` only if a source note says so; otherwise use `unknown` notes.
6. Run validation, readiness, source audit, alias index, relation validation, and search-index rebuild after every batch.

## Promotion gates
- `sourced-stub`: name and source URL only.
- `verified-core-fields`: school, rank or rank label, health when listed, world/zone/location, and source URL are present.
- `combat-core-ready`: verified core fields are complete enough for basic bot-risk reasoning.
- `strategy-ready`: spells, cheats, drops, and strategy notes are populated or explicitly source-verified as absent.

Never let Codex use `sourced-stub` or `partial` records as final gameplay truth.
