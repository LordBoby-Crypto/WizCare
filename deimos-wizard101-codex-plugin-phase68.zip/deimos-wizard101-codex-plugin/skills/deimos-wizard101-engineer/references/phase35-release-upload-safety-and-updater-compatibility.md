# Phase 35 release upload safety and updater compatibility

Use these checks when Codex edits release workflows, updater code, PyInstaller packaging, or GitHub Release assets.

Stable updater-facing assets:

- `Deimos.exe`
- `Deimos.exe.sha256`
- `release-manifest.json`

Do not rename these raw assets unless the updater compatibility contract is updated in the same change.

Required checks:

```bash
python .codex/scripts/deimos_release_upload_safety.py . .codex/reports/phase35-release-upload-safety.json
```

After Windows build:

```bash
python .codex/scripts/deimos_checksum_release_artifacts.py . .codex/reports/release-checksum-report.json --write --require-artifact
python .codex/scripts/deimos_release_upload_safety.py . .codex/reports/phase35-release-upload-safety-postbuild.json --require-artifact
```

The checksum file must use a stable SHA256 contract:

```text
<64-hex-sha256>  Deimos.exe
```
