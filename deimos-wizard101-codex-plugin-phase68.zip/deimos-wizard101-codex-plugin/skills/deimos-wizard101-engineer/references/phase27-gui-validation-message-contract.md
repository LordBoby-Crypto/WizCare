# Phase 27: GUI Validation Message Contract

Use this when adding bot validation messages, popups, status labels, or confirmation dialogs to Deimos.

## Required keys

- `validate_bot`
- `bot_validation_title`
- `bot_validation_errors`
- `bot_validation_warnings`
- `bot_validation_run_anyway`
- `bot_validation_cancelled`
- `bot_validation_no_issues`
- `bot_validation_unknown_command`
- `bot_validation_bad_arguments`
- `bot_validation_bad_coordinate`
- `bot_validation_bad_selector`
- `bot_validation_unknown_zone`
- `bot_validation_missing_combat_marker`

## Placeholder policy

Keep placeholder names identical across languages. For example, if English uses `{command}`, Chinese must also include `{command}`.

## Severity policy

- Error: parser violation likely to fail at runtime or produce undefined behavior.
- Warning: unknown Wizard101 link, missing strategy record, incomplete database maturity, or ambiguous zone alias.
- Info: validation succeeded or found only advisory notes.

## UX policy

- Errors block `Run Bot`.
- Warnings allow a localized confirm-run-anyway prompt.
- No-issue validation should not spam the user unless they explicitly clicked a validation button.
