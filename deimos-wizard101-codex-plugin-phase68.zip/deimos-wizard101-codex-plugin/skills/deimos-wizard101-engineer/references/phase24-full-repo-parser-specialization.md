# Phase 24: full-repo parser specialization

Use this reference after a full Deimos repo ZIP/check-out is available. Phase 24 supersedes the earlier partial-repo adapter smoke tests.

## Confirmed Deimos surfaces

- `src/command_parser.py`: legacy raw command bot runtime. It supports client-prefixed commands such as teleport, walkto/goto, sendkey, waitforbattle, waitforzonechange, waitforfree, usepotion, buypotions, relog, click, friendtp, entitytp, and tozone.
- `src/deimoslang/`: structured DeimosLang tokenizer/parser/IR/VM runtime for richer bot/script logic.
- `src/config_combat.py`: string combat config wrapper around WizSprinter combat config grammar. It supports per-client splitting with `###pX` markers.
- `libs/wizsprinter/.../traversalData/`: Deimos-side world/zone/path aliases that must be mapped into Wizard101 knowledge records before route/bot claims are made.
- `src/gui/tab_actions.py`: GUI bot import/export/run/kill entry point.
- `src/questing.py`, `src/sigil.py`, `src/drop_logger.py`: quest, sigil, and drop-oriented automation surfaces.

## Required workflow before Codex edits bot/combat/pathing code

1. Run `deimos_full_repo_adapter_report.py <repo> <out>`.
2. Run `deimos_command_surface_report.py <repo> <out>`.
3. Run `deimos_traversal_w101_link_report.py <repo> <out>`.
4. If release/localization files are touched, run `deimos_release_locale_full_repo_report.py <repo> <out>`.
5. Treat memory hooks, combat automation, teleport/pathing, drop logging, and sigil code as high-review surfaces.

## Safety and quality guardrails

- Do not add stealth, anti-detection, bypass, or game-protection-circumvention behavior.
- Do not infer exact Wizard101 facts from Deimos traversal aliases alone; link them to source-backed W101 records.
- Do not claim a generated/updated bot fully supports a boss, dungeon, cheat, questline, or farming route unless the W101 data maturity allows it.
- Preserve the existing GUI import/export/run/kill flow unless explicitly changing the bot editor.
