# Wizard101 Source Policy

Use this file before importing, copying, or redistributing Wizard101 data.

## Source tiers

1. **User-provided data**: files, notes, bot data, exports, and curated records supplied by Zachariah. Prefer this for automation-specific facts.
2. **Repo-derived data**: zone names, bot metadata, settings, and in-repo behavior extracted from Deimos.
3. **Official public sources**: Wizard101 guide, official update notes, official announcements, and public support docs. Use for core systems and patch timelines.
4. **Community public sources**: Wizard101 Central Wiki and public guides. Use for broad entity coverage, but preserve source metadata and check terms/permissions before bulk redistribution.
5. **Strategy/meta sources**: guides, forum notes, videos, and personal recommendations. Mark these as strategy/opinion with date and confidence; never store as hard facts without verification.

## Non-negotiable data rules

- Attach `sources[]` to every factual record.
- Track `retrieved_at`, `source_url`, `source_name`, and `source_kind` when available.
- Do not claim complete coverage unless `coverage_report.py` and source audit support it.
- Do not bulk-copy copyrighted prose into records. Store facts, normalized fields, source references, and short notes.
- Keep raw public-source exports in `data/wizard101/imports/raw/` only when permitted by the source and needed for normalization.
- Prefer user-supplied or generated structured data for redistributable packages.
