# Phase 21 spell strategy scaffolding

Phase 21 adds conservative strategy scaffolds for exact spell records, item-card links, spellement links, and spellwrighting tracks.

## Allowed uses

- Display exact spell lookup facts that are source-grounded.
- Validate that a pet, item card, boss drop, or spellement link points to a known spell family.
- Flag missing exact fields, missing spellwrighting branches, or missing strategy review.
- Generate reports showing why a claim remains locked.

## Locked uses

Do not claim any of the following from exact spell data alone:

- best spell
- best PvP spell
- best PvE rotation
- best spellwrighting path
- best farming spell
- safe automated cast order

## Promotion rule

A spell strategy record may only unlock recommendations when it explicitly includes: exact spell facts, current PvE/PvP/raid context, school/build assumptions, enemy or boss cheat context when relevant, route/farming source context, and a `strategy_reviewed` or equivalent field.
