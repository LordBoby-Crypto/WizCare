# Phase 34: Release Artifact Workflow Hardening

Use these checks when Codex changes GitHub Actions, PyInstaller packaging, release packaging, or updater-facing release assets.

Required release-facing artifacts:

- `dist/Deimos.exe`
- `dist/Deimos.exe.sha256`
- `dist/release-manifest.json`
- optional versioned ZIP containing the exe, checksum, manifest, and license

Before release, run:

```bash
python .codex/scripts/deimos_release_manifest_readiness.py . .codex/reports/phase34-release-manifest-readiness.json
```

After a real Windows build, run:

```bash
python .codex/scripts/deimos_checksum_release_artifacts.py . .codex/reports/release-checksum-report.json --write --require-artifact
```

Do not publish if checksum, manifest, or workflow artifact audit reports contain blockers. Treat missing `dist/Deimos.exe` as a pre-build warning only unless `--require-artifact` is used.
