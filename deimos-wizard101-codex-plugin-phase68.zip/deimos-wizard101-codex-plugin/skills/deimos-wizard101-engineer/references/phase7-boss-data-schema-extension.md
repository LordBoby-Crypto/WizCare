# Phase 7 boss data extension

Phase 7 extends enemy records with optional fields under `automation`, `priority`, and `data_quality`. These fields are allowed by `enemy.schema.json` through additional properties.

Example:

```json
{
  "priority": {
    "phase7_priority_score": 95,
    "priority_reasons": ["skeleton-key", "cheats", "farming-value"]
  },
  "automation": {
    "bot_readiness": "cheat-aware-ready",
    "access_constraints": ["stone-skeleton-key"],
    "risk_flags": ["manual-review-required"]
  }
}
```
