# Phase 13 - loot-type guardrails

Codex must classify Wizard101 loot by intended use before modifying Deimos behavior:

- `gear`, `hat`, `robe`, `boots`, `wand`: may need exact item stats and comparison buckets.
- `spellement` and `spellement-quantity`: useful for spell progression but not gear ranking.
- `treasure-card`: useful as consumable/support loot; do not infer spell unlocks.
- `reagent`: crafting utility; route value depends on crafting demand and drop efficiency.
- `housing`: cosmetic/housing utility; normally low bot-priority unless explicitly requested.
- `skeleton-key`: access/economy utility; can be high value but requires route review.
- `jewel`: requires a later jewel schema pass before socket/build recommendations.

Never combine these into one generic "good drop" score without a strategy-reviewed weighting model.
