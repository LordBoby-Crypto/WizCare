# Wizard101 Data Schema

The database is divided into factual records and dated strategy/meta records.

## Shared fields

Every factual record should include:

- `id`: stable kebab-case unique identifier
- `name`: display name
- `aliases`: alternate names and spelling variants
- `kind`: entity category
- `sources`: list of source metadata objects
- `last_verified`: ISO date if known
- `notes`: short curated notes only

## Core entity categories

- `world`: Spiral/world-level container.
- `zone`: mapped area, location, sublocation, dungeon, gauntlet, or instance.
- `quest`: quest giver, objectives, prerequisites, rewards, and order links.
- `npc`: quest giver, vendor, trainer, crafting NPC, event NPC, or story NPC.
- `enemy`: mob, boss, elite, minion, cheating boss, raid enemy, or skeleton key boss.
- `gear`: equippable item, jewel, mount, pet item, pack item, bundle item, or crowns item.
- `spell`: player, enemy, item card, treasure card, shadow, astral, weaving/fusion/spellement-related spell.
- `pet`: pet species, talents, derby powers, item cards, sources, and hatching notes.
- `drop`: relation record connecting source enemy/chest/pack/vendor/event to item/reagent/spellement/etc.
- `strategy`: dated recommendations for gear, farming, cheats, PvP, raids, questing, builds, or automation.
- `patch_change`: dated game changes and affected systems/entities.

## Automation metadata

When relevant, records should include an `automation` block with:

- `risk_level`: low, medium, high, manual, unknown
- `requires_instance_handling`
- `requires_sigils`
- `teleport_allowed`
- `mark_allowed`
- `solo_only`
- `multi_client_notes`
- `cheat_handling_required`
- `pathing_notes`
