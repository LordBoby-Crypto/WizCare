# Enemy detail requirements

Enemy records are central for bot generation and validation. Do not treat a creature stub as enough for automation decisions.

## Required fields for a detailed enemy

- name and aliases
- enemy type: mob, elite, boss, skeleton-key boss, raid boss, gauntlet boss, event creature
- school or mixed school, including astral/shadow variants if applicable
- world, zone, exact location(s)
- rank, health, classification, minions if known
- natural/spell list, including blades, shields, heals, auras, polymorphs, summons, and interrupts when known
- cheats with trigger, effect, timing, and counter strategy
- drops with category, school/level relevance, farm value, and source confidence
- extractability / monstrology flags if relevant
- automation notes: instance/dungeon, cheat risk, solo/team, multi-client recommendation, pathing hazards, manual-only steps

## Detail status

- `stub`: page/title/category record only.
- `partial`: some structured fields exist, but important automation fields are missing.
- `detailed`: enough structured fields exist to guide Deimos bot review.
- `verified`: recently source-checked, relationship-validated, and manually reviewed.
