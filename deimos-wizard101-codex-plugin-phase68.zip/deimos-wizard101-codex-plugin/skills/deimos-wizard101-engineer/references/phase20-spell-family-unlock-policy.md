# Phase 20 Spell-Family Unlock Policy

Use this before Codex edits spell-family, bot-combat, PvP, or farming-route logic.

1. Verify the exact spell record in `spells.json`.
2. Verify source links in `spell_links.json`.
3. Verify visible thresholds in `spellwrighting.json`.
4. Run `lambent_spell_family_report.py` and `spell_family_unlock_guardrail_report.py`.
5. Do not infer best spells, rotations, spellwrighting paths, or PvP meta from exact spell facts.
6. Treat source pages with animation/image stubs as data that may still be mechanically useful but not presentation-complete.
