# Phase 17 Exact Pet/Mount Batch Expansion

Phase 17 expands exact-page pet data for the remaining King Borr Tier 1 collection drops where pages could be verified.

Promoted to exact-page core-ready:

- Harpy
- Imp
- Night Hawk
- Raven

Already exact-page core-ready from Phase 16:

- Fenric
- Fenrir
- Snow Ram

Still locked because exact pages could not be verified in this environment:

- Fenris
- Pesky Beetle
- Tawny Ram

## Required behavior

Codex may use exact core fields for verified records: school, type, trade/kiosk status, pedigree, egg, attributes, visible talents, derby powers, item cards, and acquisition sources.

Codex must not infer hatch value, combat meta value, best pet status, route efficiency, or mount stat value without strategy-reviewed comparison records.
