# Phase 25: DeimosLang and raw-bot parser deepening

Phase 25 turns the full-repo adapter into parser-level contracts for the actual Deimos bot surfaces.

## Raw command bot contract

`src/command_parser.py` handles plain text bot commands through `parse_command(clients, command_str)`. Validators must recognize top-level commands (`kill`, `sleep`, `log`) and client-scoped actions (`teleport`, `walkto`, `sendkey`, `waitforbattle`, `waitforzonechange`, `friendtp`, `entitytp`, `tozone`, and related aliases). Raw validators must never execute commands; they only classify, warn, and link route/combat assumptions.

## DeimosLang contract

`src/deimoslang` is a compiler/runtime pipeline:

1. `tokenizer.py` maps keywords, commands, expressions, player selectors, strings, numbers, XYZ/orient/path literals, and comments.
2. `parser.py` turns tokens into command, block, loop, condition, expression, and function-like structures.
3. `sem.py` performs semantic checks.
4. `ir.py` lowers commands into instructions.
5. `vm.py` executes instructions against Deimos runtime state.

Codex must not update only one stage when a language feature needs corresponding tokenizer/parser/IR/VM support.

## Combat config contract

`src/config_combat.py` delegates Sprinty combat configs and splits per-player sections with `###pX`. The plugin can validate marker structure, but it must not invent combat strategies or school rotations without strategy-unlocked Wizard101 records.

## Zone/route contract

`traversalData/displayZones.txt` is the Deimos-side alias source. It supports route validation and linking, but it is not a complete Wizard101 encyclopedia source by itself.
