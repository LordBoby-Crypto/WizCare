# Phase 8 Tiered Boss Data Policy

Tiered boss records must never be collapsed into a single boss record for automation. A tier can change level range, rank, health, spell access, cheats, outgoing stats, drop eligibility, and bot safety.

## Maturity policy

- `stub`: title/source only.
- `partial`: core tier fields and at least source-grounded combat facts.
- `verified`: core fields plus source-checked spells, cheats, and drops.
- `strategy-reviewed`: verified record plus Deimos-specific bot/deck/route strategy review.

## Bot policy

If a boss has a late-join cheat, Deimos workflows must require synchronized client entry or flag the route as unsafe. If a boss punishes Feint, traps, blades, or minion defeat order, bot logic must either avoid those actions or require a manual-tested strategy profile.
