# Phase 30 - Release/version consistency

Phase 30 reconciles the patched Deimos main repo after the GUI bot validator work.

## Applied repo patch

- `Deimos.py` remains the version authority because the running app passes `tool_version` into the GUI and update/release surfaces.
- `pyproject.toml` was changed from `3.13.0` to `3.13.1` so package metadata matches the application version.
- Do not change release versions opportunistically. If the release owner wants a new release number, update both files together and rerun `scripts/deimos_version_consistency_report.py` and `scripts/deimos_release_readiness_report.py`.

## Required checks before release work

1. Run `python scripts/deimos_version_consistency_report.py <repo>`.
2. Run `python scripts/deimos_release_readiness_report.py <repo>`.
3. Confirm locale key parity between `locale/en.lang` and `locale/zh.lang`.
4. Confirm GUI bot validator files still compile.
5. Confirm any release artifact/workflow changes are intentional.

## Codex behavior

When a user asks for release prep, updater changes, package metadata changes, or version bumps, Codex must load this reference and treat version mismatch as a blocker.
