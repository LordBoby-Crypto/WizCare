# Phase 7: high-impact boss enrichment

Use this reference when Codex is enriching Wizard101 boss/enemy data or using enemy data to modify Deimos bot behavior.

## Priority classes

Prioritize boss records in this order:

1. Skeleton key bosses: access costs keys and mistakes can waste resources.
2. Cheating bosses: automation logic must avoid triggering punishments.
3. Spellement-dropping bosses: farming value and repeatability matter.
4. Raid and gauntlet bosses: coordination, instance constraints, and manual-check risk are high.
5. Common farming targets and arc/world final bosses.

## Required fields before bot use

A boss record is not safe for bot strategy unless it has source-grounded values for:

- world and zone/location
- boss type/classification
- school, health, rank when available
- whether cheats exist
- cheat trigger/effect/counter notes when cheats exist
- instance/key/gauntlet/raid access notes
- farming/drop summary or explicit drop-gap marker
- automation risk notes

## Maturity and readiness

- `sourced-stub`: title/category only. Never use for gameplay logic.
- `disambiguation`: route to tier/variant pages before use.
- `combat-core-ready`: school/health/rank/location are known, but cheats/drops may still need enrichment.
- `boss-core-ready`: access constraints and boss-level automation risk are known.
- `cheat-aware-ready`: cheat triggers/effects/counters are source-grounded.
- `strategy-reviewed`: strategy/farming advice has been reviewed separately from facts.

## Codex rule

Never convert category membership into gameplay truth. Category membership can prioritize enrichment, but page-level data must supply bot-relevant facts.
