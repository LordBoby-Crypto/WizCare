# Phase 5 Data Quality Gates

Use these gates when deciding whether Wizard101 facts are safe for coding decisions.

## Stub

A record may be `stub` when it has only a title, category source, or URL. Stubs are useful for search and planning, but not gameplay logic.

Required:

- id
- name
- kind
- at least one source

## Partial

A record may be `partial` when one or more domain facts have been parsed from a source page but critical fields are still missing.

Examples:

- enemy has school but not spells/cheats
- quest has name/world but not objectives
- gear has name/type but not stats/source

## Verified

A record may be `verified` only when its critical fields for that category are present and every field came from a source with a URL or user-provided data file.

Enemy verified minimum:

- school or explicit unknown-school note
- health/rank or explicit unavailable note
- location/world/zone or explicit unknown-location note
- spells-used or explicit no-spells/unknown-spells note
- cheats or explicit no-cheats/unknown-cheats note
- drops or explicit no-drops/not-extracted note
- source URL

## Strategy-reviewed

A record may become `strategy-reviewed` only after factual verification plus a curated strategy review. Use this for best gear, farming routes, meta builds, boss strategy, automation safety, and bot recommendations.

## Stale-risk

Apply `stale-risk` when the record relates to current/seasonal/patch-sensitive systems such as events, PvP, raids, Crown Shop items, packs, or new-world gear.
