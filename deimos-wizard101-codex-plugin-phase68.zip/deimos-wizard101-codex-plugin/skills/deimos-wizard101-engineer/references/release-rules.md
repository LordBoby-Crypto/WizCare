# Release readiness rules

Before a release, run/check:

- version consistency
- locale key consistency
- PyInstaller required data/binary assets
- workflow artifact names
- Rust helper build status if helpers are used
- changelog/release notes
- no local absolute paths or debug-only URLs
