# Phase 23 - Adapter extension guide

Add new adapters when the real Deimos repo reveals more precise bot file formats.

## Adapter pattern

Each adapter should return:

```json
{
  "path": "relative/file/path",
  "adapter": "metadata-tagged",
  "confidence": 0.9,
  "metadata": {
    "world": ["Wizard City"],
    "zone": ["Haunted Cave"],
    "boss": ["Lord Nightshade"]
  },
  "signals": ["@boss", "@zone", "risk:cheat"],
  "warnings": []
}
```

## Add an adapter when

- The repo has a recurring bot grammar.
- There are structured command blocks or headers.
- The file format can identify zone, quest, boss, enemy, client count, farming goal, or combat assumptions.
- A parser can avoid false positives better than raw alias matching.

## Do not add an adapter when

- The format is a one-off note.
- The parser would execute code.
- The parser requires game credentials or a live client.
- The parser would encourage stealth, bypass, anti-detection, or account-abuse behavior.
