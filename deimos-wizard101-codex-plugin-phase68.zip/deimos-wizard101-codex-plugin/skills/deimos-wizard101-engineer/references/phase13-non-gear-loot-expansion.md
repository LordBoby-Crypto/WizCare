# Phase 13 - King Borr non-gear loot expansion

Purpose: expand King Borr Tier 1 beyond gear into non-gear loot useful for bot planning and player-facing farming goals.

Included Phase 13 loot families:
- housing drops
- skeleton keys
- treasure cards
- reagents
- explicit spellement quantity rows
- visible jewel rows

Rules:
- Treat these as drop-table presence records, not drop-rate estimates.
- Do not rank farming efficiency without strategy-reviewed drop-rate/route data.
- Do not treat jewel records as complete jewel stat/socket records yet.
- Preserve level-gate and Participation Trophy warnings.
- Keep best-gear logic separate from non-gear farming goals.

Reports:
```bash
python scripts/king_borr_loot_type_coverage_report.py data/wizard101 --out phase13-king-borr-loot-type-coverage.json
python scripts/spellement_quantity_matrix.py data/wizard101 --out phase13-spellement-quantity-matrix.json
python scripts/non_gear_farming_guardrail_report.py data/wizard101 --out phase13-non-gear-farming-guardrail-report.json
```
