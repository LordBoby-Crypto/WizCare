# Phase 6 Bot Readiness Policy

Codex must distinguish encyclopedia completeness from bot-readiness. A creature record can be useful for bot routing before it is strategy-complete, but the output must say what is missing.

## Bot-safe minimum
For basic zone/battle risk checks, require school, rank/health when listed, world, zone, exact location or room, and whether it is a boss/instance/dungeon.

## Strategy-safe minimum
For farming or combat recommendations, additionally require known spells, cheats, drops, minions/allies, and school/level relevance.

## Refuse-to-assume cases
If a boss is suspected to cheat, is a skeleton key boss, raid boss, gauntlet boss, challenge mode boss, event creature, or high-level farm target, Codex must not invent strategy. It should mark the record `needs_enrichment` and ask/run the enrichment workflow.
