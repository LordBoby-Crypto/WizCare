# Phase 19: Spellwrighting and spellement expansion

Phase 19 promotes selected spell records from link-only to exact spell-page core records and creates a separate `spellwrighting.json` collection for visible tier thresholds.

## Added/updated

- `Grendel's Amends` exact core spell record and spellwrighting track.
- `Hammer of Thor` exact core spell record and spellwrighting track.
- `Ratatoskr's Spin` exact core spell record and spellwrighting track.
- `Burning Rampage` exact core spell record and spellwrighting track.
- Lambent Fire Tier 1 spellement source links for Brave Sir Badger, Burning Rampage, Catalan, Deer Knight, Handsome Fomori, Sacred Charge, and Wreckin' Ettin.

## Critical guardrail

Exact spell facts and spellwrighting thresholds are lookup data. They are not strategy recommendations. Do not recommend PvP builds, bot rotations, or upgrade paths until a strategy-reviewed record explicitly unlocks that use.
