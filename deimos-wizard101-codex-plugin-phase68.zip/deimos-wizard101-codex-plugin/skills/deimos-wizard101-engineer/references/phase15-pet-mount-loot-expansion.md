# Phase 15 - Pet and Mount Loot Expansion

Phase 15 adds typed pet and mount drop records from King Borr Tier 1. Treat these as collection/drop facts only. A boss drop table can verify that a pet or mount appears as loot, but it does not verify pet talents, item cards, derby powers, hatching value, mount speed, or mount stat bonuses.

## Added source-visible pets

Fenric, Fenrir, Fenris, Harpy, Imp, Night Hawk, Pesky Beetle, and Raven are stored as King Borr Tier 1 pet drop records.

## Added source-visible mounts

Snow Ram and Tawny Ram are stored as King Borr Tier 1 mount drop records. The source row states the mount section is 1-Day unless otherwise noted, and these two rows are marked Permanent.

## Required follow-up

Import exact pet and mount pages before making claims about talents, item cards, speed, stats, hatch value, or best collection priorities.
