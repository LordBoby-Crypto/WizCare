# Phase 5 Source and Snapshot Policy

Large raw page dumps should not be bundled inside the installable skill if they threaten the skill upload limit. Store full snapshots in repo-local caches or external data packs, then keep compact normalized records in the skill.

## Source fields

Every record should keep:

- source name
- source kind
- source URL
- retrieved date
- confidence
- whether the record is public-source, user-provided, or repo-derived

## Snapshot fields

Snapshots may include:

- title
- page id
- revision id
- URL
- retrieved date
- text extract
- wikitext extract

Do not treat snapshots as parsed truth until enrichment and validation have run.
