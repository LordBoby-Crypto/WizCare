# Phase 53 Helper Install Dry-Run Harness Integration

When working on Deimos updater install behavior, require the helper/install-harness integration checks before proposing or applying install changes. Treat any request to enable non-dry-run behavior as blocked unless a later explicit install-unlock phase changes the policy.

Required checks:
- `python .codex/scripts/deimos_helper_install_dryrun_contract.py . .codex/reports/phase53-contract.json`
- `python .codex/scripts/deimos_helper_install_dryrun_integration.py .codex/reports/phase53-integration.json`
- `python .codex/scripts/deimos_phase53_helper_install_dryrun_readiness.py . .codex/reports/phase53-readiness.json`

Pass criteria:
- helper exits 0 in dry-run mode
- helper log contains `checksum_verified` and `dry_run_complete`
- fake install harness scenarios pass
- report says `real_install_attempted=false`, `install_execution_enabled=false`, and `non_dry_run_enabled=false`
