# Known risks

- Version-string regressions can break update comparisons.
- GUI changes often miss localization updates.
- PyInstaller packages can miss new helper binaries or data files.
- Public Wizard101 data may be stale, incomplete, or contradictory.
- Strategy/meta advice changes after patches and must include verification dates.
- Bot logic can fail when zone names, aliases, dungeon state, client count, or boss cheats are wrong.
