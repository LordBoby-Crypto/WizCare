# Phase 33 - Windows Build Command Hardening

Use this reference before asking Codex to run or modify Windows build/release commands for Deimos.

## Goal

Phase 33 adds non-mutating checks that answer three questions before release work:

1. Is the repo ready for the expected Windows PyInstaller command?
2. Do GitHub workflows and local commands consistently use `Deimos.spec`?
3. If a build artifact exists, does `dist/Deimos.exe` have a size/hash report and matching checksum file?

## Expected local Windows build sequence

```bash
uv python install
uv sync --group dev
uv run --group dev pyinstaller --noconfirm --clean Deimos.spec
```

Do not replace `Deimos.spec` with a raw `pyinstaller Deimos.py` command unless the user explicitly asks for a one-off diagnostic build.

## Artifact policy

Before a build, missing `dist/Deimos.exe` is a warning only. After a build, run:

```bash
python .codex/scripts/deimos_release_artifact_report.py . .codex/reports/phase33-release-artifact-report.json --require-artifact
```

A release is blocked if the executable is missing in required mode or if `dist/Deimos.exe.sha256` does not match the executable hash.

## Codex behavior

When Codex edits build, release, or packaging files, it should run:

```bash
python .codex/scripts/deimos_windows_release_smoke.py . .codex/reports/phase33-windows-release-smoke.json
```

If the report has blockers, fix those before proposing a release.
