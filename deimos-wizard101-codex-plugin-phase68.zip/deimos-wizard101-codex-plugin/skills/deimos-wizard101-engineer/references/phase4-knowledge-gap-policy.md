# Phase 4 Knowledge Gap Policy

The project goal is exhaustive Wizard101 knowledge, but the current bundled data is still incomplete. Codex must label data maturity clearly.

## Data maturity labels

- `stub`: title/source only; do not use for gameplay decisions.
- `partial`: some fields parsed; safe only for the fields that have sources.
- `verified`: core fields present with source metadata.
- `strategy-reviewed`: a human/curated strategy layer has reviewed the fact for bot/meta use.
- `stale-risk`: the record may have changed due to patches, events, or wiki age.

## Answering rules

- Never claim all enemies/quests/gear are present until coverage reports show complete category ingestion and enrichment.
- For code changes, prefer conservative behavior when data is missing.
- If a bot feature depends on a missing field, add fallback handling or surface an "unknown/unverified" state.
- Keep source metadata on all factual records.
- Keep strategy/meta recommendations separate from facts.

## Skill packaging rule

The installable skill should stay under the upload limit. Large raw snapshots, full crawls, images, or page dumps should be external data packs or repo-local caches, not bundled into the skill ZIP unless they remain small.
