# Phase 26 - Command argument contract

Use this reference when adding or modifying Deimos commands, DeimosLang aliases, raw command parser behavior, GUI bot editor validation, or bot-file linting.

## Contract policy

- Keep raw command aliases and DeimosLang aliases synchronized only when the runtime supports the same behavior.
- Do not add a GUI command or bot command without documenting its selector behavior, required arguments, optional arguments, and validation rules.
- Do not make Codex infer runtime behavior from names alone. Use the parser source and contract reports.
- New command validators should be static and conservative.

## High-priority argument shapes

- `sleep/wait/delay`: numeric seconds, non-negative.
- `teleport/tp/setpos`: closest mob, quest position, client title, or `xyz(x,y,z)`.
- `walkto/goto/glideto/lookat`: require `xyz(x,y,z)` or a DeimosLang expression that evaluates to location.
- `setorient`: require `orient(pitch,roll,yaw)`.
- `sendkey/press`: require a keycode and optional hold duration.
- `waitforzonechange`: optional `from <zone>` or `to <zone>` target.
- `tozone`: require a traversal path or identifier; validate against traversalData when possible.
- `click/cursor`: optional numeric x/y pair.
- `clickwindow/waitforwindow/cursorwindow`: require a window path or path expression.
- `entitytp`: optional `nav`, then exact or vague entity name.
- `friendtp`: `icon` or friend name.
- `###pX`: combat config marker for one-indexed client X.

## Output rule

When a validator produces warnings, summarize the exact file/line and what Codex should inspect next. Do not silently auto-fix pathing or combat behavior.
