# Phase 29 Applied GUI Validator Build

Phase 29 applies the Phase 28 GUI bot validator patch to the full `Deimos-Wizard101-main(17).zip` repo.

Use this reference when reviewing or continuing from the patched repo ZIP.

## Applied files

- `src/gui/bot_validation.py`: local static validator for bot editor scripts.
- `src/gui/tab_actions.py`: imports `validate_bot_script` and gates `ExecuteBot` in the Run Bot callback.
- `locale/en.lang` and `locale/zh.lang`: appended bot-validation keys.
- `.codex/reports/phase29_applied_gui_validator_patch.json`: compile/static/smoke-test report.

## Guardrails

- The validator is conservative and local. It must not execute bot scripts.
- Unknown commands should remain warnings unless the parser contract proves they are invalid.
- Warning-only scripts may be run after user confirmation; error scripts must be blocked.
- Keep localization keys paired across English and Chinese.
- Do not combine this GUI validator patch with the unrelated version mismatch fix unless the user explicitly asks for release cleanup.

## Required checks

Run:

```bash
python .codex/scripts/validate_phase29_gui_validator_patch.py . .codex/reports/phase29_validate_applied_patch.json
python -m py_compile src/gui/bot_validation.py src/gui/tab_actions.py
```
