# Phase 9 - Best Gear Guardrails

Codex must not answer best-gear questions from family-level records alone.

## Allowed statements from Phase 9 data

- A boss page lists a drop family.
- A boss page lists a spellement family.
- A farm route is a candidate for later strategy review.
- Exact item stats are missing and must be imported before ranking.

## Blocked statements until later phases

- "This is the best gear" unless exact stats and a strategy-reviewed ranking exist.
- "This boss is optimal to farm" unless route timing, key cost, combat setup, drop value, and alternatives are reviewed.
- "This drop is guaranteed" unless a source explicitly says it is guaranteed.

## Deimos bot behavior

If a Deimos change uses drop/gear data to recommend or generate bots, require:

1. combat-core-ready enemy record,
2. cheat-aware strategy when cheats exist,
3. tier and level-range validation,
4. drop family/source validation,
5. explicit UI text that incomplete drop/gear data is advisory.
