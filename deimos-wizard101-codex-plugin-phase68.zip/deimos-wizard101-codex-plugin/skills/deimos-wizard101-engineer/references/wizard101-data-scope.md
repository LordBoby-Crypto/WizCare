# Wizard101 knowledge scope

The long-term goal is exhaustive current Wizard101 coverage useful for Deimos/Codex engineering:

- quests, questline order, worlds, zones, sublocations, NPCs
- enemies, enemy schools, ranks, health, spells used, cheats, minions, combat behavior
- bosses, skeleton key bosses, gauntlets, raids, cheat scripts, strategies
- drops, gear, jewels, spells, schools, pets, talents, mounts and bonuses
- fishing, gardening, monstrology, crafting, reagents, badges, housing
- spellements, PvP, events, crowns items, packs, bundles
- level progression, meta builds, best gear by level/school, farming routes
- patch changes, current systems, known limitations, automation implications

Completeness is data-driven. A category is complete only when import/validation coverage says it is complete.
