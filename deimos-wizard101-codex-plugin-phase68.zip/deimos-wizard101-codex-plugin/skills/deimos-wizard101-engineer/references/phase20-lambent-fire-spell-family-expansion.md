# Phase 20: Lambent Fire spell-family exact expansion

Phase 20 promotes the Lambent Fire Tier 1 spellement family from source links to exact spell-page core records where the page could be verified.

## Exact spell records added or updated

- Brave Sir Badger
- Catalan
- Deer Knight
- Handsome Fomori
- Sacred Charge
- Wreckin' Ettin

Burning Rampage was already exact-page ready from Phase 19 and remains part of the Lambent Fire family matrix.

## Rules

- Exact spell records are lookup data, not strategy recommendations.
- Spellwrighting thresholds are visible tier thresholds, not upgrade-path advice.
- Lambent Fire drop links verify source relationships only, not route efficiency.
- Keep bot rotation, PvP meta, and spell priority claims locked until a strategy-reviewed record says otherwise.
