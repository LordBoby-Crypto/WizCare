# Phase 12 - low-level best-gear lock

Codex must not answer with definitive best gear from the King Borr/Grizzleheim Lore dataset yet.

Allowed:
- list exact stat-ready imported items
- list King Borr Tier 1 visible gear drops
- say which comparison buckets have some coverage

Blocked:
- best-in-slot claims
- school ranking claims
- farming efficiency claims beyond source-grounded route guardrails

Unlock condition: at least three stat-ready comparable items in the same level, slot, school/scope bucket, plus a strategy review record.
