# Phase 18: Spell and Item-Card Enrichment

Phase 18 connects exact spell records to pet item cards and boss spellement drops. Use this reference when Codex changes Deimos bot logic that depends on a spell, pet item card, spellwrighting, or spellement farm.

Rules:
- Use exact spell facts only when `data_quality.exact_spell_page_verified` is true.
- Do not convert an item-card link into a rotation recommendation.
- Do not treat a spellement drop as proof of spell utility, school meta value, or upgrade path.
- If a spell record is `source-pending` or `spellement-drop-linked-only`, Codex may mention drop/link presence but must not fill in pip cost, damage, PvP status, or strategy.

Phase 18 exact spell records include Mythic Fuel, Blizzard, Spirit Trap, Spirit Blast, and Humongofrog. Lycian Chimera remains link-only because exact spell-page verification was blocked in this phase.
