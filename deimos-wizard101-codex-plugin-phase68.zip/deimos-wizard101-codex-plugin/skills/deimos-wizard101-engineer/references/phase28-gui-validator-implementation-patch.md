# Phase 28: GUI validator implementation patch

Phase 28 upgrades the previous GUI integration plan into a copy-ready patch scaffold for the real Deimos repo.

## Added behavior

- Add `src/gui/bot_validation.py` as a pure-Python preflight validator for Bot tab text.
- Patch `src/gui/tab_actions.py` so `run_bot_callback()` validates before queuing `GUICommandType.ExecuteBot`.
- Block empty scripts and hard validation errors.
- Warn on unknown commands, unusual coordinate shapes, long waits, and combat-marker metadata gaps.
- Add matching locale keys for `locale/en.lang` and `locale/zh.lang`.

## Required checks before applying

1. Confirm the repo is the main baseline, not the ignored `3.14.0-dev` branch.
2. Inspect `src/gui/tab_actions.py` and verify `build_bot_tab()` still has the same ExecuteBot queue point.
3. Append locale keys to both language files.
4. Run `python .codex/scripts/deimos_gui_validation_patch_static_check.py .` after applying.
5. Compile the new module with `python -m py_compile src/gui/bot_validation.py`.

## Safety rules

- Do not execute bot text during validation.
- Keep unknown commands as warnings unless the command is definitely unsupported by both raw commands and DeimosLang.
- Do not claim Wizard101 entity validation is complete here; Phase 28 only adds GUI-side structural validation.
- Do not block advanced users from running warning-only scripts; ask for confirmation.
