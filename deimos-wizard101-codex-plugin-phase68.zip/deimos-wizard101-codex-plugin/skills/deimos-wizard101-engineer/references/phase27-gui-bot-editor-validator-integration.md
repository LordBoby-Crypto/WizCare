# Phase 27: GUI Bot Editor Validator Integration

Use this reference before adding validation behavior to the Deimos bot editor or changing `src/gui/tab_actions.py`.

## Goal

Connect the parser-aware validation tools from Phase 26 to the user-facing bot editor without changing execution semantics or breaking legacy bot scripts.

## Required behavior

- Validate bot text before `GUICommandType.ExecuteBot` is queued.
- Treat parser errors as blockers.
- Treat unknown Wizard101 links, missing strategy coverage, and incomplete knowledge records as warnings unless the user explicitly requested strict mode.
- Never execute or import bot text as Python while validating.
- Preserve `KillBot`, import, export, and recent-import behavior.
- Keep validation fast enough to run from the GUI thread or move only expensive checks to a future backend command.

## Preferred integration point

`src/gui/tab_actions.py` currently builds the bot tab and queues `GUICommandType.ExecuteBot` from `run_bot_callback`. Add validation immediately before the queue call.

## Localization contract

All user-visible strings must go through `ctx.tl(...)`. Add every new key to both `locale/en.lang` and `locale/zh.lang`. Preserve placeholders such as `{command}` and `{zone}` across languages.

Run:

```bash
python .codex/scripts/deimos_gui_validation_message_contract.py . .codex/reports/gui_validation_messages.json
```

## Reporting commands

```bash
python .codex/scripts/deimos_gui_bot_editor_integration_report.py . .codex/reports/gui_bot_editor_integration.json
python .codex/scripts/deimos_gui_command_surface_guardrail.py . .codex/reports/gui_command_surface.json
python .codex/scripts/deimos_gui_validation_patch_plan.py . .codex/reports/gui_validation_patch_plan.md
```

## Do not

- Do not add GUI validation that rejects all unknown commands before the raw-command/DeimosLang contract is reviewed.
- Do not add English-only popups.
- Do not change `ExecuteBot` payload shape without tracing backend handling.
- Do not conflate bot parser validity with best-route, best-spell, or best-gear strategy.
