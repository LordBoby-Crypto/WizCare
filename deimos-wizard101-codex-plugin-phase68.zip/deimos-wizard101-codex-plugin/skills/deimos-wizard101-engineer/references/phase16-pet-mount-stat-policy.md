# Phase 16 pet/mount stat policy

Do not treat drop-table pet or mount rows as stat records.

## Pet facts

Allowed from exact pet page:

- school
- type / first-generation status
- trade/kiosk status
- pedigree
- attributes
- item cards
- talents
- derby abilities
- acquisition sources

Still locked:

- best pet for a school
- hatch value
- meta relevance
- combat recommendation

## Mount facts

Allowed from exact mount page:

- passengers
- movement speed
- stat boost status
- duration/cost options
- drop/vendor/acquisition sources

Still locked:

- route efficiency
- farming route ranking
- travel optimization claims

Snow Ram is now exact-page core-ready as a +40% movement mount with no stat boost. Tawny Ram remains locked until exact page retrieval succeeds.
