# Repo engineering rules

- Prefer small, reviewable changes.
- Preserve existing behavior unless the user asks for a rewrite.
- Do not invent external APIs. Inspect current code first.
- When adding settings, update defaults, UI, persistence, localization, and usage sites.
- When adding a GUI command, trace command creation, dispatch, popup/UI state, and error handling.
- When adding files required at runtime, update PyInstaller packaging and release workflows.
- Always flag untested runtime behavior.
