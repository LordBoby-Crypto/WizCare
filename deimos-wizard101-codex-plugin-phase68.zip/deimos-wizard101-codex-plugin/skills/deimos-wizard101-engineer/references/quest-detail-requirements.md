# Quest detail requirements

Quest records are detailed only when they support questline order, bot validation, and route planning.

## Required fields for a detailed quest

- quest name and aliases
- world, zone, exact starting location
- quest giver and turn-in NPC
- prerequisites and next quest IDs
- objective list in order: talk, explore, defeat, collect, interact, dungeon, craft, fish, garden, pet, PvP, raid, event
- objective targets and counts
- rewards: XP, gold, items, spells, training points, badges, access unlocks
- branch/side/mainline classification
- level requirement when applicable
- automation notes: pathing difficulty, instance handling, combat requirements, collect/drop randomness, manual-only restrictions

## Questline integrity

- Every prereq and next quest should resolve to a known quest ID or be marked unresolved.
- Every objective location should resolve to a known zone/location or be marked unresolved.
- Every combat target should resolve to an enemy/boss or be marked unresolved.
