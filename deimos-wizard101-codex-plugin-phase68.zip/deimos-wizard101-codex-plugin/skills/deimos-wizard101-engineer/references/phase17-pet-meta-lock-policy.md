# Phase 17 Pet Meta Lock Policy

Even when exact pet pages are imported, meta recommendations remain locked.

Do not say a pet is best, meta, optimal, worth farming, or worth hatching unless there is a separate strategy record that compares:

- current PvE/PvP use case
- talent pool quality
- item card relevance
- hatch accessibility
- alternatives by school and level
- farming cost/time
- current patch relevance

Exact-page facts are lookup facts, not strategy decisions.
