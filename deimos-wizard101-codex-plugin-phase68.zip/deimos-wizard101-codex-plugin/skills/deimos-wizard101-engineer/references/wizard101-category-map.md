# Wizard101 category map

Map public Wizard101 category pages into local collections. Prefer stable category/list pages for stubs, then detailed item pages for enrichment.

| Local collection | Public category/list source examples | Notes |
|---|---|---|
| worlds | Basic:Locations | Source of world/location/sub-location taxonomy. |
| zones | Basic:Locations, location pages | Must preserve instance/dungeon/gauntlet markers. |
| quests | Category:Quests, Basic:Quests | Import as stubs first, then enrich objectives/order. |
| npcs | Category:NPCs | Distinguish quest givers, vendors, trainers, housing NPCs. |
| enemies | Category:Creatures, Boss, Creatures by School, Creatures by World | Use enemy-detail requirements before trusting combat data. |
| bosses | Boss subcategory, Skeleton Key Bosses, gauntlet pages | Store as enemies with `is_boss: true`. |
| drops | creature/item pages | Drops are relationship records: source enemy/location -> item. |
| gear | Category:Items, Gear Search, item subcategories | Track stats, level, school, source, sockets, item cards. |
| jewels | Category:Jewels, Jewel Locator | Track socket type, school, level, stat grants, source. |
| spells | Category:Spells, Basic:Spells, spell school categories | Track school, pips, type, effects, train/source, PvP flags. |
| pets | Category:Pets, Pet Locator | Track body, school, cards, talents, hatch/source. |
| pet talents | Pet Talent Locator | Track talent type, effect, rarity, pool/source. |
| mounts | Category:Mounts | Track speed, stat bonus, source, duration/permanent. |
| fishing | Fishes, Fish Locator | Track school, rank, locations, chest fish, seasonal flags. |
| gardening | Gardening, seeds | Track seed, likes/dislikes, drops, pests, ranks. |
| monstrology | Monstrological Creatures | Track extractability and animus use. |
| crafting/reagents | Crafting, recipes, reagents | Track recipe, vendor, cooldown, reagent sources. |
| badges | Basic:Badges | Track category, requirements, world/event. |
| housing | Housing, Castle Magic, gauntlets | Track item/house/gauntlet, source, interaction limits. |
| spellements | spellement-dropping creatures, spell pages | Track source and upgrade path. |
| raids | Raids pages, patch notes | Track requirements, bosses, cheats, rewards. |
| PvP | official guide, update notes, PvP pages | Track rules/meta separately from facts. |
| events | Special Events, official event pages | Track recurrence, activities, rewards. |
| crowns items/packs/bundles | Crown Shop / pack / bundle pages | Track availability and source date. |
| skeleton key bosses | Skeleton Key Bosses | Track key type, location, cheats, drops. |
| gauntlets | Housing gauntlet pages | Track entry rules, teleport/mark limits, drops. |
| cheats | boss/creature pages | Store normalized trigger/effect/counter strategy. |
| strategy/meta | curated strategy records | Must include date, confidence, and source type. |
| patch changes | official update notes, Central announcements | Store date/version, affected systems, impact notes. |
