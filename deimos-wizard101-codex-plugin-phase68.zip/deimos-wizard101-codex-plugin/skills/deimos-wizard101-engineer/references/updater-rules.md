# Updater rules

When reviewing or modifying updater behavior:

- Verify the app version source in `Deimos.py`.
- Check release asset names and checksum assets.
- Check helper binary path assumptions.
- Check PyInstaller includes helper binaries and data files.
- Check CI builds any Rust helpers before packaging.
- Fail gracefully on network, checksum, permission, or in-use executable errors.
