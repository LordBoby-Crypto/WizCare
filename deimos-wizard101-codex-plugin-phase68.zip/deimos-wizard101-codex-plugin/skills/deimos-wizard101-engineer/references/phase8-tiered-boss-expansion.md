# Phase 8: Tiered Boss Expansion

Phase 8 expands disambiguated skeleton-key/spellement bosses into exact tier records. Do not use a disambiguation page as a combat source for Deimos bot logic. Always select the exact tier record by boss name, tier, level range, world, zone, and source URL.

## Rules

- Treat tier as a required field for tiered bosses.
- Treat level-gated drops as incomplete until drop tables are separately enriched.
- Treat cheat lists as high-priority for bot/deck behavior.
- Treat late-join cheats as multi-client timing blockers.
- Keep records at `partial` until full spells, drops, and strategy review are complete.

## Phase 8 enriched families

- King Borr Tier 1-4.
- Lambent Fire Tier 1-4.

## Scripts

- `scripts/tiered_boss_matrix.py <data_dir>` groups tier records by base boss.
- `scripts/tiered_boss_gap_report.py <data_dir>` reports missing tier fields and strategy gaps.
- `scripts/tiered_boss_bot_rules.py <data_dir>` generates conservative bot rules from cheat fields.
