# Deimos repo architecture

## Baseline
Treat `Deimos-Wizard101-main` as the active baseline for this project. Ignore `3.14.0-dev` unless explicitly requested.

## Major areas
- `Deimos.py`: application entrypoint and version source.
- `src/gui/`: GUI tabs, commands, popups, helpers, and settings UI.
- `src/`: core Python modules and managers.
- `locale/*.lang`: language keys. Add/update paired keys when GUI text changes.
- `libs/wizlaunch/`: Rust launcher/helper logic.
- `.github/workflows/`: CI/build/release workflows.
- `Deimos.spec`: PyInstaller packaging rules.

## Expected repo-brain behavior
When Codex modifies the repo, it must identify adjacent files that need synchronized changes: GUI command definitions, tab handlers, localization, settings defaults, spec packaging, workflows, tests/scripts, and docs.
