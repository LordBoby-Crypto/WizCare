# Phase 24 command, combat, and navigation contract

## Raw command bots

Raw bot lines are interpreted by `parse_command(clients, command_str)`. Most action commands require a client selector such as `p1`, `p1:p2`, `except p2`, or `mass`, then an action.

Codex must preserve aliases when refactoring. For example, `teleport`, `tp`, and `setpos` are linked; `walkto` and `goto` are linked; `waitforbattle` and `waitforcombat` are linked.

## Combat configs

`src/config_combat.py` delegates text combat configs by `###pX` markers. If no client marker exists, the whole config is applied to all fallback clients. Any Codex change to combat config handling must preserve this contract unless explicitly requested.

## DeimosLang

`src/deimoslang/` contains tokenizer/parser/semantic/IR/VM stages. Codex should change these as a compiler pipeline, not as unrelated files.

## Navigation aliases

`displayZones.txt`, `zoneMap.txt`, `gates_list.txt`, `interactiveTeleporters.txt`, `objectLocations.txt`, and `uniqueObjectLocations.txt` are Deimos navigation data. They are not the full Wizard101 world database, but they are the best repo-side pathing aliases and should be linked against W101 zone/location records.
