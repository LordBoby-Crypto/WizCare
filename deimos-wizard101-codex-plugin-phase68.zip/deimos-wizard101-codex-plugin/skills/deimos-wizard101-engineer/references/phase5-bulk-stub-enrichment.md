# Phase 5 Bulk Stub and Enrichment Workflow

Phase 5 turns the enemy-first framework into repeatable batch work. Its purpose is to let Codex collect large category stubs safely, queue enrichment targets, fetch page snapshots, parse detail fields, and keep all incomplete records labeled honestly.

## Default Phase 5 pipeline

1. Import or update category stubs.
2. Build an enrichment queue for records with the largest bot impact.
3. Fetch page snapshots for a small batch.
4. Run conservative parser enrichment.
5. Run gap, source, maturity, and bot-impact reports.
6. Rebuild search indexes.
7. Only use `verified` or `strategy-reviewed` records for code behavior that would affect automation decisions.

## Recommended enemy enrichment priority

Prioritize records in this order:

1. Main-story bosses and cheating bosses.
2. Skeleton key bosses and gauntlet bosses.
3. Spellement-dropping creatures.
4. World hub mobs used in common defeat/collect quests.
5. Farming bosses with valuable drops.
6. Event creatures and retired creatures last unless the task concerns that event/history.

## Batch size guidance

Use small enrichment batches first. For example:

```bash
python scripts/build_enrichment_queue.py data/wizard101 --kind enemies --limit 25 --out queue/enemies-next.json
python scripts/import_mediawiki_page_snapshots.py --titles queue/enemies-next.json --out snapshots/enemies
python scripts/enrich_creature_records.py data/wizard101
python scripts/promote_data_maturity.py data/wizard101
python scripts/creature_gap_report.py data/wizard101 --out reports/creature-gaps.json
```

## Repo-development rule

When Codex changes Deimos bot behavior, it must not silently assume complete Wizard101 knowledge. If the relevant record is `stub` or `partial`, add fallback behavior, warning labels, or manual-review flags.
