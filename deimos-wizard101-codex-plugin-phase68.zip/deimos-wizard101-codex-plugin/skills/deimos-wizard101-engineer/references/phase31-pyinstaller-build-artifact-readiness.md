# Phase 31 - PyInstaller and build artifact readiness

Phase 31 standardizes build checks around `Deimos.spec` and release artifacts.

## Rules for Codex

- Prefer `uv run --group dev pyinstaller --noconfirm --clean Deimos.spec` for CI, release, and local release builds.
- Do not use a raw `pyinstaller ... Deimos.py` command unless the command duplicates every required `Deimos.spec` data, hidden import, manifest, version, and icon setting.
- Before release work, run `scripts/deimos_pyinstaller_build_readiness.py <repo>`.
- Treat missing locale bundling, missing icon/manifest/version file, or version mismatch as blockers.
- Treat workflows that still use raw PyInstaller commands as warnings or blockers depending on whether they are release-gating.
- Keep `src/gui/bot_validation.py` importable from `src/gui/tab_actions.py`; PyInstaller will include it through normal static import once the Phase 29 patch is applied.

## Phase 31 applied repo change

The patched repo changes `.github/workflows/ci.yml` from a raw one-file PyInstaller command to the same `Deimos.spec` build path used by release workflows. This reduces the chance that CI passes while release packaging fails, or that CI omits locale/WizSprinter data hidden in the spec.
