# Phase 16: exact pet/mount enrichment

Use exact pet and mount pages to promote King Borr pet/mount drop records from `drop-source-stub` to `exact-page-core-ready`.

## Promotion requirements

A pet can only be promoted when the exact page verifies at least: school, type, trade/kiosk status, pedigree or attributes if available, item card data, talents, derby abilities, and acquisition sources.

A mount can only be promoted when the exact page verifies at least: passengers, speed bonus, stat boost status, duration/cost options where listed, and acquisition sources.

## Locks that remain after promotion

Exact page data is still not enough for:

- best pet recommendations
- hatch value recommendations
- route optimization
- mount route value
- pet combat build ranking

Those require strategy-reviewed records.
