# Phase 23 - Real Deimos repo adapter layer

Phase 23 upgrades the integration layer from generic bot-file inventory into a real adapter framework for Deimos bot and automation files.

## Purpose

Codex must not assume every Deimos bot is the same shape. Before editing bot, route, quest, farm, combat, deck, or automation files, it should:

1. Probe likely files and classify the format.
2. Extract explicit metadata tags when present.
3. Infer possible Wizard101 entities from filenames and content.
4. Validate extracted metadata against the local Wizard101 knowledge database.
5. Report missing, ambiguous, or low-maturity entities before making gameplay-specific code changes.

## Supported adapter classes

Phase 23 recognizes these adapter classes conservatively:

- `metadata-tagged`: files with `@zone`, `@world`, `@boss`, `@enemy`, `@quest`, `@school`, `@level`, `@clients`, `@spell`, or `@farm` tags.
- `plain-text-bot`: text/script files with Wizard101 entity names or command-like route lines.
- `python-automation`: Python files under bot/route/quest/farm/combat/script paths.
- `json-metadata`: JSON files that contain keys such as `zone`, `world`, `boss`, `enemy`, `quest`, `school`, `level`, `clients`, `spell`, or `farm`.
- `yaml-metadata`: YAML-like files that contain the same metadata keys.
- `unknown-bot-like`: files in likely bot paths that do not have enough structure yet.

## Required Codex behavior

Before changing a bot file:

```bash
python scripts/deimos_bot_format_probe.py <repo> --out bot-format-probe.json
python scripts/deimos_bot_metadata_validator.py <repo> <data_dir> --out bot-metadata-validator.json
python scripts/deimos_bot_knowledge_patch_plan.py <repo> <data_dir> --out bot-knowledge-patch-plan.json
```

If the validator reports unresolved `zone`, `world`, `boss`, `enemy`, `quest`, or `spell` references, Codex must either enrich the Wizard101 database first or mark the code change as knowledge-blocked.

## Non-goals

The adapter layer does not execute bots, automate gameplay, bypass protections, or add stealth/anti-detection behavior. It only reads files, extracts metadata, and validates repo/game-knowledge consistency.
