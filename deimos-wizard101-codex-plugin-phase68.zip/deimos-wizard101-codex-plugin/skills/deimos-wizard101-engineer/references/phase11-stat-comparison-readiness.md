# Phase 11 - Stat Comparison Readiness

Use this reference before ranking gear.

A gear item is eligible for ranking only when it has:

1. exact item-page stats,
2. a clear item slot,
3. school relevance,
4. level requirement,
5. acquisition method,
6. comparable alternatives in the same level/slot/school bucket, and
7. a strategy-reviewed note explaining why it is preferred.

Until those conditions are met, expose the item as a candidate or lookup record only.
