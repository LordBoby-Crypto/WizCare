# Bot system rules

- Resolve current world/zone through normalized aliases.
- Consider client count and compatibility requirements.
- Prefer zone-specific bots over general bots only when metadata matches.
- Validate bot assumptions against quest, enemy, boss, cheat, and route data.
- Mark bots requiring manual steps or high-risk combat.
- Never silently run imported bot content without user-controlled confirmation.
