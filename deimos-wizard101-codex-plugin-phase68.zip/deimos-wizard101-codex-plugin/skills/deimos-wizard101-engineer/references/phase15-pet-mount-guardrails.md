# Phase 15 - Pet and Mount Guardrails

Use these guardrails when Codex changes Deimos bot recommendations, farming routes, loot summaries, or UI labels involving pets and mounts.

1. Do not rank pets by combat value from drop tables alone.
2. Do not infer mount speed or stat bonuses from a creature page.
3. Separate collection farming from combat/gear farming.
4. For King Borr Tier 1 recommendations, preserve the level 1-30 requirement and Participation Trophy warning for out-of-range wizards.
5. Require exact item/pet/mount pages plus strategy review before unlocking best-pet, best-mount, or speed/stat claims.
