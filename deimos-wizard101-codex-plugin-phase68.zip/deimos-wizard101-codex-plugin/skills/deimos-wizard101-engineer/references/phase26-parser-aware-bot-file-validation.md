# Phase 26 - Parser-aware bot file validation

Use this reference before editing Deimos bot files, raw-command scripts, DeimosLang scripts, combat configs, route/pathing scripts, or GUI bot-editor behavior.

## Purpose

Phase 26 turns the Phase 25 parser contracts into runnable pre-edit validation. The validator is intentionally static: it must not import Deimos, import WizWalker, connect to Wizard101, or execute any bot script.

## Required pre-edit checks

Run these scripts against the full Deimos repo before changing bot/combat/pathing code:

```bash
python scripts/deimos_command_argument_contract.py <repo> <out.json>
python scripts/deimos_parser_aware_bot_validator.py <repo> <out.json>
python scripts/deimos_zone_entity_link_validator.py <repo> data/wizard101 <out.json>
python scripts/deimos_combat_marker_coverage.py <repo> <out.json>
```

## Interpretation rules

- Treat parser errors as blockers unless the user explicitly asks to repair those files.
- Treat parser warnings as review prompts, not automatic failures.
- Do not validate traversalData files as bot scripts; they are route/navigation datasets.
- If the repo does not ship user bot files, report that no bot files were found instead of claiming validation coverage over user bots.
- Validate `xyz(...)` and `orient(...)` as three-value tuples. Do not infer missing coordinates.
- Validate `tozone`/`waitforzonechange` target strings against traversalData aliases when possible.
- Validate `###pX` combat config markers as positive integer client sections and flag duplicate/empty sections.

## Deimos command surfaces covered

Phase 26 validators cover these surfaces:

- raw `src/command_parser.py` command-line scripts
- DeimosLang command aliases from `src/deimoslang/tokenizer.py`
- DeimosLang simple command contracts from `src/deimoslang/parser.py`
- Sprinty combat configs and `###pX` delegation markers
- WizSprinter traversalData display-zone and object-location link checks

## Guardrails

Codex must not claim a bot file is game-safe only because it is parser-valid. Parser-valid means the command shape is acceptable. Game-safe still requires Wizard101 knowledge checks for zone, boss, enemy, cheat, quest, drop, and strategy maturity.
