# Phase 22 - Bot file validation policy

Codex must treat Deimos bot files as executable/user-action automation assets. Do not rewrite them blindly.

## What to scan

Scan likely bot files by extension and path:

- `.txt`, `.bot`, `.json`, `.yaml`, `.yml`, `.py`, `.md`
- paths containing `bot`, `bots`, `route`, `routes`, `quest`, `farm`, `script`, `scripts`, `combat`, `deck`

Skip dependency/build folders such as `.git`, `.venv`, `venv`, `dist`, `build`, `target`, `node_modules`, and `__pycache__`.

## What to extract

Extract conservative signals:

- Wizard101 zones/worlds/bosses/enemies/spells/gear names by alias match.
- Metadata-style tags such as `@zone`, `@world`, `@boss`, `@enemy`, `@clients`, `@school`, and `@level`.
- Risk terms: `feint`, `blade`, `trap`, `aura`, `late join`, `minion`, `cheat`, `skeleton key`, `tier`, `dungeon`, `gauntlet`, `sigil`, `teleport`, `mark`.

## Blocking rules

Block or flag bot upgrade claims when:

- The target zone/boss/enemy is unresolved.
- The linked enemy/boss maturity is below `combat-core-ready` and the change touches combat behavior.
- The bot references cheats but the database has no verified cheat fields.
- The bot references drops/gear/spells but those records are only source stubs.
- The requested change would create stealth, anti-detection, bypass, credential, account-abuse, or unattended exploit behavior.

## Output expectations

Reports must be JSON so Codex can quote exact blockers and next actions. Human summaries should include:

- Files scanned.
- Bot files detected.
- Matched Wizard101 entities.
- Unresolved references.
- Risk terms found.
- Recommended enrichment before coding.
