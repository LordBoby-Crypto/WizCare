# Phase 23 - Bot metadata contract

Use this metadata contract when creating or updating Deimos bot files. Existing bots may not follow it yet; do not mass-rewrite them unless asked.

## Recommended tags

Place tags near the top of a bot/route/quest/farm file when the format allows comments:

```text
@world: Wizard City
@zone: Haunted Cave
@boss: Lord Nightshade
@enemy: Lord Nightshade
@quest: The Dark of Nightshade
@school: Death
@level: 10
@clients: 1
@farm: boss drops
@spell: Blizzard
```

## Meaning

- `world`: Wizard101 world or major area.
- `zone`: exact zone/location used by the bot.
- `boss`: boss target, if any.
- `enemy`: mob/enemy target, if any.
- `quest`: quest target, if any.
- `school`: player school assumption or target enemy school, depending on the bot file; describe ambiguity in comments.
- `level`: player level/range assumption.
- `clients`: required hooked client count.
- `farm`: farming goal such as spellements, gear, reagent, mount, pet, badge, or key.
- `spell`: spell or item-card assumption.

## Validation rules

- Tags should match a record in the Wizard101 database whenever possible.
- Combat bots require `boss` or `enemy` records with at least `combat-core-ready` maturity before Codex makes combat-specific changes.
- Farming bots require linked drop/gear/spell/pet/mount/reagent records before Codex claims the route is good for that farming goal.
- Strategy claims require `strategy-reviewed` records.

## Backward compatibility

For existing untagged files, Codex should infer likely entities from filenames/content and generate a patch plan rather than rewriting the file immediately.
