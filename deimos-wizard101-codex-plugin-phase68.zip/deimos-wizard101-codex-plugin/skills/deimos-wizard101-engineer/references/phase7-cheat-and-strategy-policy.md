# Phase 7 cheat and strategy policy

Cheat data is high-risk. Preserve source wording only as short summaries and store structured trigger/effect/counter fields. If a cheat is uncertain, store a gap rather than guessing.

## Structured cheat fields

Each cheat entry should prefer:

- `trigger`: what player/enemy action starts it
- `effect`: what the boss/minion does
- `counter`: safe counterplay or "verify manually"
- `source_note`: short source-grounded note

## Automation classifications

- `avoid-late-join`: late joins can trigger punishment.
- `avoid-feint`: normal Feint may be removed or punished.
- `avoid-unprotected-blades`: blades/charm actions may be removed/punished.
- `avoid-shadow-creatures`: Shadow creature spells may trigger a response.
- `manual-review-required`: cheats are too complex or under-specified.

## Strategy separation

Do not mark a boss `strategy-reviewed` just because facts are present. Strategy-reviewed means a separate strategy record has reviewed farming value, school-specific setup, team size, and Deimos bot safety.
