"""Conservative GitHub release update helpers for Deimos.

This module is intentionally review-first. It can inspect GitHub release
metadata, select stable updater-facing assets, download files to a staging
directory, and verify SHA-256 checksums. It does not replace Deimos.exe,
restart the application, or launch a self-update helper.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import hashlib
import json
import re
import tempfile
import urllib.error
import urllib.request


DEFAULT_REPO = "Deimos-Wizard101/Deimos-Wizard101"
STABLE_EXE_ASSET = "Deimos.exe"
STABLE_CHECKSUM_ASSET = "Deimos.exe.sha256"
STABLE_MANIFEST_ASSET = "release-manifest.json"
USER_AGENT = "Deimos-Wizard101-update-check/1.0"


@dataclass(frozen=True)
class ReleaseAsset:
    name: str
    download_url: str
    size: int | None = None
    content_type: str | None = None


@dataclass(frozen=True)
class ReleaseInfo:
    tag_name: str
    name: str | None
    html_url: str | None
    prerelease: bool
    draft: bool
    assets: dict[str, ReleaseAsset]
    raw: dict[str, Any]

    def asset(self, name: str) -> ReleaseAsset | None:
        return self.assets.get(name)


@dataclass(frozen=True)
class UpdateCheckResult:
    current_version: str
    latest_version: str | None
    update_available: bool
    release: ReleaseInfo | None
    warnings: tuple[str, ...]


class UpdateSystemError(RuntimeError):
    """Raised when release update metadata or staged assets are invalid."""


def normalize_version(value: str) -> tuple[int, ...]:
    """Return a comparable numeric version tuple from common tag strings.

    Examples:
        "v3.13.1" -> (3, 13, 1)
        "3.14.0-dev" -> (3, 14, 0)
    """
    nums = re.findall(r"\d+", value or "")
    return tuple(int(n) for n in nums[:4]) or (0,)


def is_newer_version(latest: str, current: str) -> bool:
    return normalize_version(latest) > normalize_version(current)


def _request_json(url: str, timeout: float = 15.0) -> dict[str, Any]:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise UpdateSystemError(f"GitHub returned HTTP {exc.code} for {url}") from exc
    except urllib.error.URLError as exc:
        raise UpdateSystemError(f"Could not reach GitHub release API: {exc.reason}") from exc


def parse_release(payload: dict[str, Any]) -> ReleaseInfo:
    assets: dict[str, ReleaseAsset] = {}
    for item in payload.get("assets") or []:
        name = str(item.get("name") or "")
        url = str(item.get("browser_download_url") or "")
        if not name or not url:
            continue
        assets[name] = ReleaseAsset(
            name=name,
            download_url=url,
            size=item.get("size"),
            content_type=item.get("content_type"),
        )
    return ReleaseInfo(
        tag_name=str(payload.get("tag_name") or ""),
        name=payload.get("name"),
        html_url=payload.get("html_url"),
        prerelease=bool(payload.get("prerelease")),
        draft=bool(payload.get("draft")),
        assets=assets,
        raw=payload,
    )


def get_latest_release(repo: str = DEFAULT_REPO, include_prereleases: bool = False) -> ReleaseInfo:
    if include_prereleases:
        payload = _request_json(f"https://api.github.com/repos/{repo}/releases")
        if not isinstance(payload, list):
            raise UpdateSystemError("Unexpected GitHub releases response")
        for release in payload:
            info = parse_release(release)
            if not info.draft:
                return info
        raise UpdateSystemError("No non-draft releases found")
    return parse_release(_request_json(f"https://api.github.com/repos/{repo}/releases/latest"))


def validate_release_assets(release: ReleaseInfo) -> tuple[str, ...]:
    warnings: list[str] = []
    if not release.tag_name:
        warnings.append("release is missing tag_name")
    for required in (STABLE_EXE_ASSET, STABLE_CHECKSUM_ASSET):
        if required not in release.assets:
            warnings.append(f"release is missing stable asset {required}")
    if STABLE_MANIFEST_ASSET not in release.assets:
        warnings.append(f"release is missing optional manifest asset {STABLE_MANIFEST_ASSET}")
    checksum = release.assets.get(STABLE_CHECKSUM_ASSET)
    if checksum and checksum.size is not None and checksum.size > 4096:
        warnings.append("checksum asset is unexpectedly large")
    return tuple(warnings)


def check_for_update(current_version: str, repo: str = DEFAULT_REPO, include_prereleases: bool = False) -> UpdateCheckResult:
    release = get_latest_release(repo=repo, include_prereleases=include_prereleases)
    warnings = list(validate_release_assets(release))
    latest = release.tag_name.lstrip("v") if release.tag_name else None
    return UpdateCheckResult(
        current_version=current_version,
        latest_version=latest,
        update_available=bool(latest and is_newer_version(latest, current_version)),
        release=release,
        warnings=tuple(warnings),
    )


def parse_sha256_checksum(text: str) -> str:
    first = text.strip().splitlines()[0] if text.strip() else ""
    match = re.match(r"^([a-fA-F0-9]{64})(?:\s+\*?Deimos\.exe)?\s*$", first)
    if not match:
        raise UpdateSystemError("checksum file must contain '<64-hex-sha256>  Deimos.exe'")
    return match.group(1).lower()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def download_asset(asset: ReleaseAsset, destination: Path, timeout: float = 60.0) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(asset.download_url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp, destination.open("wb") as out:
            while True:
                chunk = resp.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
    except urllib.error.URLError as exc:
        raise UpdateSystemError(f"Could not download {asset.name}: {exc.reason}") from exc
    return destination


def stage_release_assets(release: ReleaseInfo, stage_dir: Path | None = None) -> dict[str, Path]:
    """Download stable assets into a staging directory and verify checksum.

    This is intentionally non-installing. A caller must review the result and
    implement a separate, explicit install step if self-update is desired.
    """
    warnings = validate_release_assets(release)
    missing = [w for w in warnings if "missing stable asset" in w]
    if missing:
        raise UpdateSystemError("; ".join(missing))
    stage = Path(stage_dir) if stage_dir else Path(tempfile.mkdtemp(prefix="deimos-update-"))
    exe = download_asset(release.assets[STABLE_EXE_ASSET], stage / STABLE_EXE_ASSET)
    checksum_path = download_asset(release.assets[STABLE_CHECKSUM_ASSET], stage / STABLE_CHECKSUM_ASSET)
    expected = parse_sha256_checksum(checksum_path.read_text(encoding="utf-8"))
    actual = sha256_file(exe)
    if actual != expected:
        raise UpdateSystemError(f"checksum mismatch for {STABLE_EXE_ASSET}: expected {expected}, got {actual}")
    result = {STABLE_EXE_ASSET: exe, STABLE_CHECKSUM_ASSET: checksum_path}
    manifest_asset = release.assets.get(STABLE_MANIFEST_ASSET)
    if manifest_asset:
        result[STABLE_MANIFEST_ASSET] = download_asset(manifest_asset, stage / STABLE_MANIFEST_ASSET)
    return result
