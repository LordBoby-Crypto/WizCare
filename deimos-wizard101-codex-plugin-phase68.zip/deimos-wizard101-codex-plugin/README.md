# Deimos Wizard101 Codex Plugin - Phase 50

# Deimos Wizard101 Codex Plugin - Phase 15

This package is a Codex/ChatGPT enablement bundle for making Codex better at maintaining the Deimos Wizard101 repositories while grounding gameplay-related changes in a structured Wizard101 knowledge base.

Phase 3 adds a real ingestion/indexing foundation:

- expanded Wizard101 entity schemas for worlds, zones, quests, NPCs, enemies, gear, spells, pets, drops, strategy, and patch changes
- source manifest and source-policy references for public/user/repo data
- importers for JSON, JSONL, directory batches, and MediaWiki API page exports
- normalization and deduplication pipeline
- SQLite/search-index builder
- query tool for local records
- coverage report tool
- starter world/location and patch seed records with source metadata
- repo-copy `.codex` workflows for data import, bot validation, and release safety

Important: this package is not yet a complete Wizard101 encyclopedia. It is the working system for collecting, validating, indexing, querying, and applying the encyclopedia data over time.

## Phase 3 additions

Phase 3 adds the bulk-ingestion layer: category manifests, category-member importer scaffolding, alias indexing, relationship validation, coverage matrix reporting, and source-grounded seed records for schools, source categories, and additional patch anchors.

Important: Phase 3 still does not claim complete Wizard101 coverage. It creates the machinery needed to import and validate full coverage category by category.


## Phase 4

Phase 4 starts the enemy-first bulk ingestion and bot-impact layer. It adds recursive MediaWiki category stub import tooling, conservative creature enrichment from page snapshots, creature detail gap reporting, and a Deimos bot enemy-impact report. The bundled database is still intentionally marked incomplete; use the reports to distinguish stubs, partial records, and verified records.


## Phase 5

Phase 5 adds the first bulk-stub batch from the public `Category:Creatures` member listing, enrichment queues, page snapshot fetch tooling, maturity promotion gates, source audits, and batch-status reporting. The data remains intentionally incomplete; this phase makes incompleteness measurable and actionable.


## Phase 6

Phase 6 starts page-level creature enrichment. It adds verified core-field records for Lord Nightshade and Rattlebones, adds a page-enrichment manifest, and adds reports/tools for creature priority, readiness, and safe merging of enrichment batches. The package still does not claim complete Wizard101 coverage.


## Phase 7 - High-impact boss enrichment

Phase 7 adds a boss-first enrichment layer for Codex. It focuses on skeleton key bosses, cheating bosses, spellement-dropping bosses, raid/gauntlet bosses, and common farming targets. It introduces boss priority scoring, boss readiness reporting, cheat-aware automation policy, and a seed batch for high-risk/high-value bosses. Data remains explicitly incomplete unless a page-level source has been verified.


## Phase 9 additions

Phase 9 expands exact tier handling for high-impact skeleton-key/spellement bosses. It adds tier records for King Borr Tier 1-4 and Lambent Fire Tier 1-4, plus reports and bot rules that prevent Codex from using disambiguation pages or generic boss records for automation decisions. Full spell/drop data remains a separate enrichment track.

## Phase 9 additions

Phase 9 adds drop/gear linkage for high-impact tiered bosses. It introduces source-grounded drop records for King Borr and Lambent Fire spellments/families, gear-family records for Grizzleheim Lore Pack and Knight's Spellemental Pack-related drops, and guardrail reports that prevent Codex from using incomplete family data as exact best-gear data.

New checks:

```bash
skills/deimos-wizard101-engineer/scripts/drop_gear_link_report.py skills/deimos-wizard101-engineer/data/wizard101
skills/deimos-wizard101-engineer/scripts/gear_stat_gap_report.py skills/deimos-wizard101-engineer/data/wizard101
skills/deimos-wizard101-engineer/scripts/best_gear_guardrail_report.py skills/deimos-wizard101-engineer/data/wizard101 --school Storm --level 60
skills/deimos-wizard101-engineer/scripts/boss_farming_route_report.py skills/deimos-wizard101-engineer/data/wizard101 --boss "King Borr"
```
## Phase 13 additions

Phase 13 adds exact item-stat enrichment for high-impact boss drops. It introduces exact gear records for Allfather's Gungnir (Level 20+) and Conjurer's Timeless Tunic, drop links back to King Borr, item-stat readiness reports, conservative best-gear candidate grouping, and parser scaffolding for future item pages.

Phase 13 still blocks best-gear claims unless exact ranking/comparison data exists.


## Phase 13

Phase 13 expands exact King Borr item-stat coverage with additional source-verified gear records and exact drop links. It adds reports for item stat batch coverage, school/stat coverage, boss drop completion, and best-gear unlock readiness. Best-gear ranking remains locked until comparison buckets have enough source-verified alternatives and strategy review.


## Phase 13 additions

Phase 13 adds a fuller King Borr Tier 1 visible gear-table pass, exact stat-ready records for Odin's Helm (Level 20+) and Odin's Boots (Level 20+), and reports that separate drop visibility from exact item stats and best-gear readiness. Best-gear ranking remains locked.


## Phase 13 additions

Phase 13 expands King Borr Tier 1 non-gear loot coverage: housing drops, skeleton keys, treasure cards, reagents, explicit spellement quantity rows, and visible jewel rows. It adds reports and guardrails that keep non-gear farming goals separate from exact gear-stat ranking and best-gear logic.


## Phase 14

Adds typed jewel and reagent collections for King Borr Tier 1 visible loot, socket/stat guardrails, reagent crafting-use gap reporting, and loot-type route-priority separation. Best jewel/reagent route rankings remain blocked until exact item pages, equip/crafting uses, and strategy-reviewed efficiency data are imported.


## Phase 15 additions

Phase 15 adds typed pet and mount loot expansion for King Borr Tier 1. It introduces `mounts.json`, `mount.schema.json`, pet/mount collection reports, gap reports for pet talents and mount speed/stat fields, and collection-only guardrails so Codex does not confuse pet/mount drops with combat ranking or best-gear recommendations.

Current Phase 15 policy: pet and mount records from creature drop tables are collection facts only until exact pet/mount pages are imported.


## Phase 17 update

Phase 17 adds exact pet/mount page enrichment. Fenric and Fenrir are promoted from King Borr drop-source stubs to exact-page core-ready pet records with school, item card, attributes, talents, derby abilities, and acquisition sources. Snow Ram is promoted to exact-page core-ready mount data with passengers, +40% movement speed, no stat boost, duration/cost options, and acquisition sources. Tawny Ram remains locked because exact-page verification did not complete in this environment.

New reports include pet/mount exact readiness, pet exact-page gaps, mount exact-page gaps, and pet/mount strategy guardrails.


## Phase 17 additions

Phase 17 expands exact pet-page coverage for Harpy, Imp, Night Hawk, and Raven, adds blocked exact-page retry tracking for Fenris, Pesky Beetle, and Tawny Ram, and keeps pet/mount meta recommendations locked until strategy-reviewed comparison records exist.


## Phase 18 - spell and item-card enrichment

Phase 18 adds exact spell records for selected pet item cards, creates `spell_links.json`, adds spellement-to-spell-family links for King Borr, and adds reports that keep spell strategy/meta claims locked until strategy-reviewed.


## Phase 19

Phase 19 expands spellwrighting and spellement support. It promotes selected King Borr spell families to exact spell-page records, adds a separate `spellwrighting.json` collection for visible tier thresholds, links Lambent Fire Tier 1 spellement families, and adds strategy-lock reports so Codex cannot turn raw spell facts into bot/PvP/meta recommendations without review.


## Phase 20

Phase 20 expands the Lambent Fire spell family by promoting Brave Sir Badger, Catalan, Deer Knight, Handsome Fomori, Sacred Charge, and Wreckin' Ettin to exact spell-page core records. It adds spellwrighting tracks, Lambent Fire source links, and guardrail reports that keep bot rotation, PvP, farming-route, and spellwrighting-path recommendations locked until strategy-reviewed data exists.

## Phase 21 - Spell strategy scaffolding

Phase 21 adds conservative spell strategy scaffolds, PvE/PvP separation, Deimos bot spell-usage guardrails, and reports that keep exact spell facts separate from strategy/meta recommendations. Exact spell records may be used for lookup and validation; best-spell, PvP, spellwrighting-path, and bot-rotation claims remain locked unless future strategy-reviewed records explicitly unlock them.

## Phase 23 - Deimos integration hooks

Phase 23 adds repo-facing checks that let Codex scan Deimos bot/route/automation files and link them to the local Wizard101 knowledge database before proposing gameplay-aware changes.

Added scripts:

- `deimos_bot_inventory.py`
- `deimos_bot_w101_link_report.py`
- `deimos_bot_guardrail_report.py`
- `deimos_repo_knowledge_health.py`

Added references:

- `phase22-deimos-integration-hooks.md`
- `phase22-bot-file-validation-policy.md`

No new Wizard101 factual encyclopedia records are added in Phase 23. This phase adds the bridge between repo files and the knowledge base.


## Phase 23 update

Phase 23 adds the real Deimos repo adapter layer: static bot-file format probing, metadata validation against the Wizard101 knowledge database, schema inference, and knowledge patch planning. This phase is designed for the full Deimos repo, while still smoke-testing safely against partial repos.

## Phase 24 update

Phase 24 uses the uploaded full `Deimos-Wizard101-main(17).zip` repo as the real baseline and supersedes earlier partial-repo adapter assumptions. It adds full-repo parser specialization for raw command bots, DeimosLang scripts, Sprinty combat configs, traversalData zone aliases, GUI bot editor flow, questing, sigil, and drop-logging surfaces.

Generated reports include full repo index, command surface, adapter status, release/version/locale checks, and Wizard101 traversal link targets.

## Phase 25 update

Phase 25 deepens the full-repo adapter into parser-level validation support for Deimos raw command bots, DeimosLang scripts, Sprinty combat config markers, traversal zone aliases, and GUI bot editor surfaces. It adds static validators and reports that Codex should run before editing bot/combat/pathing code.



## Phase 27 - Parser-aware bot file validation

Phase 27 adds static validators for Deimos raw-command scripts, DeimosLang-like scripts, Sprinty combat config markers, traversal zone/entity links, and command argument contracts. It uses the uploaded full `Deimos-Wizard101-main(17).zip` baseline and excludes WizSprinter `traversalData` from bot-file validation so route datasets are not mistaken for user bot scripts.

New scripts include:

- `deimos_command_argument_contract.py`
- `deimos_parser_aware_bot_validator.py`
- `deimos_zone_entity_link_validator.py`
- `deimos_combat_marker_coverage.py`

The Phase 27 reports show the full repo currently has 213 display-zone aliases, 295 zone-map entries, 234 object-location rows, 106 unique-object-location rows, and 496 gate rows. The parser-aware bot validator found no shipped user bot script corpus after excluding traversal data, so it reports zero bot-file parser errors.


## Phase 27 additions

Phase 27 adds GUI bot-editor validator integration support. It includes static reports for `src/gui/tab_actions.py`, `GUICommandType.ExecuteBot`, localization requirements, command-surface guardrails, and a conservative patch plan for adding parser-aware validation to the Deimos bot editor.

New scripts:

- `deimos_gui_bot_editor_integration_report.py`
- `deimos_gui_validation_message_contract.py`
- `deimos_gui_command_surface_guardrail.py`
- `deimos_gui_validation_patch_plan.py`

The phase keeps actual code modification separate from analysis: it tells Codex where and how to add validation safely, but does not force a Deimos source patch into the repo.

## Phase 28 update

Phase 28 adds a copy-ready GUI bot validation patch scaffold for the full main Deimos repo baseline. It includes a new pure-Python `src/gui/bot_validation.py`, a patched `src/gui/tab_actions.py`, locale key append files, static validation scripts, and a workflow for applying and testing the patch. This phase implements structural preflight validation in the GUI; it does not claim complete Wizard101 strategy validation.


## Phase 29 - Applied GUI Validator Repo Build

Phase 29 applies the GUI bot validator patch to the full `Deimos-Wizard101-main(17).zip` repo and packages a patched Deimos repo ZIP. It adds an applied-patch report, compile/static checks, bot-validator smoke tests, repo-copy apply/validate scripts, and a workflow for continuing from the patched repo.

Patched repo artifact: `Deimos-Wizard101-main-phase29-gui-validator.zip`.

Known separate issue still reported, not fixed in this phase: `Deimos.py` reports `3.13.1` while `pyproject.toml` reports `3.13.0`.


## Phase 31 update

Phase 31 adds PyInstaller/build artifact readiness checks and patches the Deimos CI workflow to build with `Deimos.spec` instead of a raw `pyinstaller ... Deimos.py` command. This keeps CI aligned with release packaging and verifies locale/logo/manifest/version-file inclusion.

Artifacts generated:

- `phase31-pyinstaller-build-readiness.json`
- `.codex/scripts/deimos_pyinstaller_build_readiness.py`
- `.codex/scripts/deimos_workflow_build_matrix.py`
- `.codex/workflows/pyinstaller-build-readiness.md`


## Phase 32 - Local build smoke and dependency readiness

Phase 32 adds local pre-build diagnostics for the patched Deimos main repo. It introduces no-mutation scripts for dependency readiness, AST/bytecode smoke checks, dependency-light `bot_validation` import tests, and an aggregate local pre-build report.

Generated: 2026-06-16T23:58:39.878876+00:00

## Phase 33 - Windows build command hardening

Phase 33 adds Windows build and release-artifact preflight checks. It keeps `Deimos.spec` as the canonical PyInstaller entrypoint, adds non-mutating Windows preflight scripts, and adds artifact size/SHA256 reporting for `dist/Deimos.exe`. Missing `dist/Deimos.exe` is warning-only before a build and a blocker only when the artifact report is run with `--require-artifact`.



## Phase 34 - Release artifact workflow hardening

Adds checksum generation, release manifest generation, workflow artifact auditing, and direct release asset checks for `Deimos.exe`, `Deimos.exe.sha256`, and `release-manifest.json`.

## Phase 35: release upload safety and updater compatibility

Phase 35 adds release/upload contract checks for stable updater-facing assets. It validates workflow asset names, checksum format, release-manifest requirements, and updater compatibility in pre-build and post-build modes.

Stable raw release assets:

- `Deimos.exe`
- `Deimos.exe.sha256`
- `release-manifest.json`

Primary repo command:

```bash
python .codex/scripts/deimos_release_upload_safety.py . .codex/reports/phase35-release-upload-safety.json
```

Post-build required command:

```bash
python .codex/scripts/deimos_release_upload_safety.py . .codex/reports/phase35-release-upload-safety-postbuild.json --require-artifact
```


## Phase 36 - Update-system scaffold

Adds conservative `src/update_system.py` infrastructure for stable GitHub release lookup, release asset validation, staged downloads, and SHA-256 verification. The scaffold intentionally does not replace or relaunch `Deimos.exe`. Use `.codex/workflows/update-system-scaffold.md` and `deimos_update_system_readiness.py` before changing updater behavior.

## Phase 39 - Manual update-check GUI integration

Phase 38 adds a safe, manual `Check for Updates` GUI action. It uses the Phase 36 update scaffold to query GitHub release metadata and report update availability, missing assets, and release links. It intentionally does not auto-install, replace `Deimos.exe`, relaunch Deimos, or run background startup checks.

Primary Deimos files:
- `src/gui/update_check.py`
- `src/gui/tab_hotkeys.py`
- `src/update_system.py`
- `locale/en.lang`
- `locale/zh.lang`

Run inside the patched repo:

```bash
python .codex/scripts/deimos_phase37_update_gui_readiness.py . .codex/reports/phase37-update-gui-readiness.json
```


## Phase 38 - staged download review flow

Phase 38 adds a manual, checksum-verified staged-download path for update assets. It lets the GUI download `Deimos.exe`, `Deimos.exe.sha256`, and optional `release-manifest.json` into a user-selected staging folder, then verifies SHA-256. It still blocks automatic installation, executable replacement, relaunch behavior, and background downloads.

Run in a patched repo:

```bash
python .codex/scripts/deimos_phase38_staged_download_readiness.py .
```


## Phase 39 - staged update manifest review UI

Phase 39 adds a review-only UI for staged update assets. It summarizes release tag, checksum status, file paths, file sizes, and optional `release-manifest.json` contents. It still forbids automatic installation, executable replacement, and relaunch behavior.

Run in a patched repo:

```bash
python .codex/scripts/deimos_phase39_manifest_review_readiness.py .
```

## Phase 40 - updater install-design review

Adds a review-only future installer design layer. Installation remains disabled; the GUI can display helper-process requirements, rollback rules, locked-file handling rules, and required user confirmations. New readiness scripts enforce that no GUI-process executable replacement behavior has been introduced.


## Phase 41 - Updater helper specification

Adds review-only external updater helper contract, helper manifest validation, rollback/exit-code rules, and readiness checks. Installation remains disabled.


## Phase 42

Adds a dry-run-only updater-helper implementation scaffold under `libs/updater_helper/`, plus contract/smoke/readiness checks. The scaffold validates manifests and SHA-256 files but does not replace or relaunch executables.


## Phase 43

Adds updater helper build packaging scaffold: PyInstaller spec, build preflight wrapper, helper packaging contract checks, and readiness reports. Install/GUI launch remains locked.

## Phase 44
Adds updater-helper executable artifact validation: stable helper artifact names, helper size/hash reporting, checksum checks, release-manifest inclusion checks, and aggregate readiness reporting. Install execution remains locked.

## PHASE45_SUMMARY
Phase 45 adds helper release-manifest integration: helper metadata checks, release asset matrix reporting, and aggregate readiness checks. The helper remains optional and install execution remains locked.


## Phase 46 - Helper release workflow integration

Phase 46 integrates updater-helper artifact build/check/upload steps into GitHub Actions while keeping helper launch and install execution locked. It adds workflow readiness scripts and reports for helper assets `deimos-updater-helper.exe` and `deimos-updater-helper.exe.sha256`.

## Phase 47 - Helper artifact post-build enforcement

Phase 47 makes helper executable/checksum artifacts mandatory after helper builds in publishing workflows (`build.yml`, `develop.yml`, and `release.yml`). It keeps CI as a non-publishing preflight workflow and keeps GUI helper launch / executable replacement locked.

Added scripts:

- `.codex/scripts/deimos_helper_postbuild_enforcement.py`
- `.codex/scripts/deimos_phase47_helper_postbuild_readiness.py`

Added workflow/reference:

- `.codex/workflows/helper-artifact-postbuild-enforcement.md`
- `.codex/references/phase47-helper-artifact-postbuild-enforcement.md`

Publishing workflows must no longer silently ignore missing helper artifacts.


## Phase 48 helper manifest post-build validation

Adds strict post-build validation for `release-manifest.json` so primary and updater-helper artifact metadata agree with built files and checksum files. Install execution remains locked.


## Phase 49

Adds updater dry-run release simulation for fake/staged artifacts. It validates checksums, release manifest, helper dry-run logs, and staged review metadata without touching a real executable or enabling install execution.


## Phase 50

Adds the updater install unlock gate. This is a review-only safety phase: install remains locked, helper launch remains locked, and executable replacement remains locked until a future phase explicitly satisfies the gate and implements installation separately.


## Phase 51 - Final update-install implementation design

Adds a design-only future install implementation plan, helper launch sequence requirements, rollback requirements, final confirmation contract, and post-install verification checks. Install execution remains locked.

## Phase 52 - Updater install test harness

Adds a simulation-only updater install harness for checksum, rollback, fake replacement, helper exit-code, and post-install verification tests. Real install execution remains locked.


## Phase 53
Adds helper install dry-run harness integration. The updater-helper scaffold now has a repeatable integration pathway with the fake install harness, validating manifest parsing, checksum verification, JSONL log events, fake replacement scenarios, rollback simulation, and exit-code behavior without touching a real executable.

## Phase 54 - Helper Dry-Run GUI Review

Adds review-only GUI support for inspecting helper dry-run command previews and existing JSONL logs from staged update files. Helper launch, non-dry-run execution, executable replacement, relaunch, and automatic install remain locked.


## Phase 55

Adds staged helper dry-run log generation from staged update files. The generated JSONL log can be reviewed by the Phase 54 GUI dialog, but helper launch, non-dry-run install, executable replacement, relaunch, and automatic install remain locked.

## Phase 56 - GUI staged helper dry-run log detection polish

Phase 56 adds review-only classification for staged helper dry-run logs: `missing`, `invalid`, `incomplete`, and `valid`. It updates the GUI staged helper dry-run review dialog, locale keys, validation scripts, workflow docs, and readiness reports. Install execution, helper launch from the GUI, non-dry-run helper execution, executable replacement, and relaunch behavior remain locked.


## Phase 57 - staged update UX/report polish

Phase 57 adds a read-only staged-update UX summary layer. It condenses checksum, manifest, helper dry-run log, and install-lock states into GUI/report-friendly status text while keeping helper launch and install execution disabled.

New repo workflow: `.codex/workflows/staged-update-ux-report-polish.md`.

## Phase 58 - staged update problem-resolution guidance
Adds display/report guidance for staged update issue states: missing assets, checksum mismatch, invalid manifest, missing/incomplete helper dry-run logs, and install-lock status. Install execution remains locked.

## Phase 59: Staged Update Self-Diagnostics Export

Phase 59 adds a review-only diagnostics export bundle for staged update issues. The bundle aggregates staged asset review, checksum state, manifest parse state, helper dry-run log status, resolution guidance, and install-lock status into a safe ZIP that excludes executable payloads.

Install execution remains locked: no helper launch, no executable replacement, no relaunch, and no non-dry-run install behavior.


## Phase 61 - Diagnostics comparison report

Adds read-only staged-update diagnostics bundle import and comparison scripts. Executable payloads are rejected; install execution remains locked.


## Phase 62

Adds read-only diagnostics comparison GUI/report polish helpers and repo-copy updates.


## Phase 63

Adds a read-only diagnostics comparison GUI action scaffold and validation scripts.


## Phase 64 - Diagnostics comparison menu/button wiring

Adds a safe `Compare diagnostics` GUI button near the update controls. The button opens two exported diagnostics ZIP bundles and displays the read-only comparison summary. Executable payload import, helper launch, and install execution remain locked.

## Phase 65 - Diagnostics comparison export/share polish

Adds safe export/share support for diagnostics comparison results. The export bundle contains comparison review metadata, the lower-level comparison report, source summaries, export metadata, and a README. Executable payloads are excluded and the updater/install path remains locked.


## Phase 66 - Diagnostics comparison export GUI polish

Adds safe GUI-facing export polish for diagnostics comparison reports: default filenames based on comparison severity/difference count, clearer saved/failed messages, detailed export summary metadata, and explicit executable-exclusion wording. Install execution, helper launch, non-dry-run behavior, executable replacement, and Deimos relaunch remain disabled.

Validation:

```bash
python .codex/scripts/deimos_phase66_diagnostics_comparison_export_gui_readiness.py
```


## Phase 67 - Diagnostics comparison exported-report import/review

Adds safe import/review for exported diagnostics-comparison report bundles. The review rejects executable payloads, summarizes comparison metadata, and keeps helper launch/install behavior locked.


## Phase 68 - Diagnostics report import GUI polish

Adds a safe GUI import/review action for exported diagnostics comparison report bundles. The action summarizes safe, blocked, malformed, and incomplete report bundles while rejecting executable payloads and keeping helper launch/install behavior locked.

Validation:

```bash
python .codex/scripts/deimos_phase68_diagnostics_report_import_gui_readiness.py
```
