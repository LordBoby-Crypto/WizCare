#!/usr/bin/env python3
"""Minimal local query facade for the Wizard101 data index.
This is a scriptable foundation for an MCP server; tools can call it directly until MCP wiring is finalized.
"""
import argparse, subprocess, sys
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
DATA = BASE / 'data' / 'wizard101'

def run_script(name, *args):
    script = BASE / 'scripts' / name
    return subprocess.call([sys.executable, str(script), *map(str, args)])

def main():
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest='cmd', required=True)
    q=sub.add_parser('query'); q.add_argument('--kind'); q.add_argument('--q', default=''); q.add_argument('--limit', default='20')
    sub.add_parser('build-index')
    sub.add_parser('coverage')
    args=ap.parse_args()
    if args.cmd == 'query':
        sys.exit(run_script('query_wizard101_data.py', DATA, '--kind', args.kind or '', '--q', args.q, '--limit', args.limit))
    if args.cmd == 'build-index':
        sys.exit(run_script('build_wizard101_index.py', DATA))
    if args.cmd == 'coverage':
        sys.exit(run_script('coverage_report.py', DATA))
if __name__ == '__main__': main()
