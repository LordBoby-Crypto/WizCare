"""Conservative GitHub release update helpers for Deimos.

This module is intentionally review-first. It can inspect GitHub release
metadata, select stable updater-facing assets, download files to a staging
directory, and verify SHA-256 checksums. It does not replace Deimos.exe,
restart the application, or launch a self-update helper.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import hashlib
import json
import re
import tempfile
import urllib.error
import urllib.request


DEFAULT_REPO = "Deimos-Wizard101/Deimos-Wizard101"
STABLE_EXE_ASSET = "Deimos.exe"
STABLE_CHECKSUM_ASSET = "Deimos.exe.sha256"
STABLE_MANIFEST_ASSET = "release-manifest.json"
USER_AGENT = "Deimos-Wizard101-update-check/1.0"


@dataclass(frozen=True)
class ReleaseAsset:
    name: str
    download_url: str
    size: int | None = None
    content_type: str | None = None


@dataclass(frozen=True)
class ReleaseInfo:
    tag_name: str
    name: str | None
    html_url: str | None
    prerelease: bool
    draft: bool
    assets: dict[str, ReleaseAsset]
    raw: dict[str, Any]

    def asset(self, name: str) -> ReleaseAsset | None:
        return self.assets.get(name)


@dataclass(frozen=True)
class UpdateCheckResult:
    current_version: str
    latest_version: str | None
    update_available: bool
    release: ReleaseInfo | None
    warnings: tuple[str, ...]


class UpdateSystemError(RuntimeError):
    """Raised when release update metadata or staged assets are invalid."""


def normalize_version(value: str) -> tuple[int, ...]:
    """Return a comparable numeric version tuple from common tag strings.

    Examples:
        "v3.13.1" -> (3, 13, 1)
        "3.14.0-dev" -> (3, 14, 0)
    """
    nums = re.findall(r"\d+", value or "")
    return tuple(int(n) for n in nums[:4]) or (0,)


def is_newer_version(latest: str, current: str) -> bool:
    return normalize_version(latest) > normalize_version(current)


def _request_json(url: str, timeout: float = 15.0) -> dict[str, Any]:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise UpdateSystemError(f"GitHub returned HTTP {exc.code} for {url}") from exc
    except urllib.error.URLError as exc:
        raise UpdateSystemError(f"Could not reach GitHub release API: {exc.reason}") from exc


def parse_release(payload: dict[str, Any]) -> ReleaseInfo:
    assets: dict[str, ReleaseAsset] = {}
    for item in payload.get("assets") or []:
        name = str(item.get("name") or "")
        url = str(item.get("browser_download_url") or "")
        if not name or not url:
            continue
        assets[name] = ReleaseAsset(
            name=name,
            download_url=url,
            size=item.get("size"),
            content_type=item.get("content_type"),
        )
    return ReleaseInfo(
        tag_name=str(payload.get("tag_name") or ""),
        name=payload.get("name"),
        html_url=payload.get("html_url"),
        prerelease=bool(payload.get("prerelease")),
        draft=bool(payload.get("draft")),
        assets=assets,
        raw=payload,
    )


def get_latest_release(repo: str = DEFAULT_REPO, include_prereleases: bool = False) -> ReleaseInfo:
    if include_prereleases:
        payload = _request_json(f"https://api.github.com/repos/{repo}/releases")
        if not isinstance(payload, list):
            raise UpdateSystemError("Unexpected GitHub releases response")
        for release in payload:
            info = parse_release(release)
            if not info.draft:
                return info
        raise UpdateSystemError("No non-draft releases found")
    return parse_release(_request_json(f"https://api.github.com/repos/{repo}/releases/latest"))


def validate_release_assets(release: ReleaseInfo) -> tuple[str, ...]:
    warnings: list[str] = []
    if not release.tag_name:
        warnings.append("release is missing tag_name")
    for required in (STABLE_EXE_ASSET, STABLE_CHECKSUM_ASSET):
        if required not in release.assets:
            warnings.append(f"release is missing stable asset {required}")
    if STABLE_MANIFEST_ASSET not in release.assets:
        warnings.append(f"release is missing optional manifest asset {STABLE_MANIFEST_ASSET}")
    checksum = release.assets.get(STABLE_CHECKSUM_ASSET)
    if checksum and checksum.size is not None and checksum.size > 4096:
        warnings.append("checksum asset is unexpectedly large")
    return tuple(warnings)


def check_for_update(current_version: str, repo: str = DEFAULT_REPO, include_prereleases: bool = False) -> UpdateCheckResult:
    release = get_latest_release(repo=repo, include_prereleases=include_prereleases)
    warnings = list(validate_release_assets(release))
    latest = release.tag_name.lstrip("v") if release.tag_name else None
    return UpdateCheckResult(
        current_version=current_version,
        latest_version=latest,
        update_available=bool(latest and is_newer_version(latest, current_version)),
        release=release,
        warnings=tuple(warnings),
    )


def parse_sha256_checksum(text: str) -> str:
    first = text.strip().splitlines()[0] if text.strip() else ""
    match = re.match(r"^([a-fA-F0-9]{64})(?:\s+\*?Deimos\.exe)?\s*$", first)
    if not match:
        raise UpdateSystemError("checksum file must contain '<64-hex-sha256>  Deimos.exe'")
    return match.group(1).lower()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def download_asset(asset: ReleaseAsset, destination: Path, timeout: float = 60.0) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(asset.download_url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp, destination.open("wb") as out:
            while True:
                chunk = resp.read(1024 * 1024)
                if not chunk:
                    break
                out.write(chunk)
    except urllib.error.URLError as exc:
        raise UpdateSystemError(f"Could not download {asset.name}: {exc.reason}") from exc
    return destination


def stage_release_assets(release: ReleaseInfo, stage_dir: Path | None = None) -> dict[str, Path]:
    """Download stable assets into a staging directory and verify checksum.

    This is intentionally non-installing. A caller must review the result and
    implement a separate, explicit install step if self-update is desired.
    """
    warnings = validate_release_assets(release)
    missing = [w for w in warnings if "missing stable asset" in w]
    if missing:
        raise UpdateSystemError("; ".join(missing))
    stage = Path(stage_dir) if stage_dir else Path(tempfile.mkdtemp(prefix="deimos-update-"))
    exe = download_asset(release.assets[STABLE_EXE_ASSET], stage / STABLE_EXE_ASSET)
    checksum_path = download_asset(release.assets[STABLE_CHECKSUM_ASSET], stage / STABLE_CHECKSUM_ASSET)
    expected = parse_sha256_checksum(checksum_path.read_text(encoding="utf-8"))
    actual = sha256_file(exe)
    if actual != expected:
        raise UpdateSystemError(f"checksum mismatch for {STABLE_EXE_ASSET}: expected {expected}, got {actual}")
    result = {STABLE_EXE_ASSET: exe, STABLE_CHECKSUM_ASSET: checksum_path}
    manifest_asset = release.assets.get(STABLE_MANIFEST_ASSET)
    if manifest_asset:
        result[STABLE_MANIFEST_ASSET] = download_asset(manifest_asset, stage / STABLE_MANIFEST_ASSET)
    return result



def _asset_size_from_path(path: Path | None) -> int | None:
    try:
        return path.stat().st_size if path and path.exists() else None
    except OSError:
        return None


def _read_manifest_json(path: Path | None) -> dict[str, Any] | None:
    if not path or not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {"raw": data}
    except Exception as exc:
        return {"parse_error": str(exc)}


def build_staged_asset_review(release: ReleaseInfo, staged_paths: dict[str, Path | str]) -> dict[str, Any]:
    """Return review-only metadata for a staged update folder.

    This helper never installs, moves, replaces, executes, or relaunches files.
    It summarizes staged file presence, sizes, checksum status, and optional
    release-manifest contents so GUI/user review can happen before any future
    install flow is considered.
    """
    normalized: dict[str, Path] = {name: Path(path) for name, path in (staged_paths or {}).items()}
    exe_path = normalized.get(STABLE_EXE_ASSET)
    checksum_path = normalized.get(STABLE_CHECKSUM_ASSET)
    manifest_path = normalized.get(STABLE_MANIFEST_ASSET)
    checksum_status = "missing"
    expected_sha256 = None
    actual_sha256 = None
    if checksum_path and checksum_path.exists() and exe_path and exe_path.exists():
        try:
            expected_sha256 = parse_sha256_checksum(checksum_path.read_text(encoding="utf-8"))
            actual_sha256 = sha256_file(exe_path)
            checksum_status = "verified" if expected_sha256 == actual_sha256 else "mismatch"
        except Exception as exc:
            checksum_status = f"error: {exc}"
    assets: list[dict[str, Any]] = []
    for name in (STABLE_EXE_ASSET, STABLE_CHECKSUM_ASSET, STABLE_MANIFEST_ASSET):
        staged = normalized.get(name)
        release_asset = release.assets.get(name) if release else None
        assets.append({
            "name": name,
            "staged_path": str(staged) if staged else None,
            "present": bool(staged and staged.exists()),
            "staged_size": _asset_size_from_path(staged),
            "release_size": release_asset.size if release_asset else None,
            "download_url_present": bool(release_asset and release_asset.download_url),
        })
    return {
        "review_only": True,
        "install_locked": True,
        "release_tag": release.tag_name if release else None,
        "release_name": release.name if release else None,
        "release_url": release.html_url if release else None,
        "checksum_status": checksum_status,
        "expected_sha256": expected_sha256,
        "actual_sha256": actual_sha256,
        "assets": assets,
        "manifest": _read_manifest_json(manifest_path),
    }

# PHASE40_INSTALL_DESIGN_REVIEW
INSTALL_REVIEW_ONLY = True
INSTALL_ENABLED = False
INSTALL_HELPER_REQUIRED = True
INSTALL_HELPER_NAME = "deimos-updater-helper.exe"


def _path_exists(value: Path | str | None) -> bool:
    return bool(value and Path(value).exists())


def build_update_install_design_review(
    release: ReleaseInfo | None,
    staged_paths: dict[str, Path | str],
    current_executable: Path | str | None = None,
) -> dict[str, Any]:
    """Return a review-only install design report for a staged update.

    This function intentionally does not install, move, replace, execute,
    relaunch, spawn helper processes, or modify Deimos.exe. It documents what a
    future installer would need to prove before executable replacement could be
    considered.
    """
    staged_review = build_staged_asset_review(release, staged_paths)
    checksum_verified = staged_review.get("checksum_status") == "verified"
    exe_asset = next((a for a in staged_review.get("assets", []) if a.get("name") == STABLE_EXE_ASSET), {})
    exe_staged = bool(exe_asset.get("present"))
    blockers: list[str] = [
        "install flow is intentionally disabled in this build",
        "external helper process is not bundled or invoked by this design review",
    ]
    if not checksum_verified:
        blockers.append("staged Deimos.exe checksum is not verified")
    if not exe_staged:
        blockers.append("staged Deimos.exe is missing")

    return {
        "review_only": True,
        "install_enabled": False,
        "install_locked": True,
        "helper_required": INSTALL_HELPER_REQUIRED,
        "helper_name": INSTALL_HELPER_NAME,
        "current_executable_path": str(current_executable) if current_executable else None,
        "current_executable_exists": _path_exists(current_executable),
        "release_tag": release.tag_name if release else None,
        "checksum_verified": checksum_verified,
        "staged_exe_present": exe_staged,
        "blockers": blockers,
        "required_user_confirmations": [
            "confirm the staged release tag matches the intended release",
            "confirm checksum verification is successful",
            "confirm Deimos will close before replacement",
            "confirm rollback backup location before replacement",
            "confirm relaunch behavior explicitly",
        ],
        "required_helper_process_behaviors": [
            "wait for the current Deimos process to exit",
            "verify staged executable checksum again immediately before replacement",
            "copy current Deimos.exe to a timestamped rollback backup",
            "atomically replace Deimos.exe only after backup succeeds",
            "verify replacement file hash after copy/rename",
            "restore rollback backup if replacement verification fails",
            "write an install log next to the staged files",
            "relaunch Deimos only when the user explicitly requested it",
        ],
        "locked_file_handling_rules": [
            "never overwrite Deimos.exe while the process is running",
            "use an external helper process for replacement after GUI exit",
            "treat PermissionError and sharing violations as non-destructive blockers",
            "leave staged files intact when a lock prevents replacement",
        ],
        "rollback_rules": [
            "create rollback backup before any replacement attempt",
            "never delete rollback backup during the same install transaction",
            "restore backup if copied file hash does not match expected SHA-256",
            "surface rollback path to the user after install attempt",
        ],
        "explicitly_forbidden_in_gui_process": [
            "os.replace on the running executable",
            "subprocess launch of staged Deimos.exe as an installer",
            "silent update installation",
            "background startup installation",
            "deleting the current executable before backup is complete",
        ],
        "future_install_steps": [
            "bundle and verify a small updater helper executable",
            "add a signed/hashed helper contract",
            "add explicit install confirmation UI",
            "close Deimos and delegate replacement to the helper",
            "verify post-install executable hash and log result",
        ],
        "staged_asset_review": staged_review,
    }

# PHASE41_UPDATER_HELPER_SPECIFICATION
HELPER_SPEC_REVIEW_ONLY = True
HELPER_SPEC_VERSION = "1.0"
HELPER_MANIFEST_NAME = "deimos-helper-manifest.json"
HELPER_LOG_NAME = "deimos-updater-helper.log"
HELPER_ROLLBACK_DIR_NAME = "rollback"
HELPER_ALLOWED_EXIT_CODES = {
    0: "success",
    1: "invalid_arguments",
    2: "manifest_validation_failed",
    3: "source_checksum_failed",
    4: "target_process_still_running",
    5: "backup_failed",
    6: "replace_failed",
    7: "post_replace_hash_failed",
    8: "rollback_failed",
    9: "user_cancelled",
    10: "unexpected_error",
}


def build_update_helper_contract() -> dict[str, Any]:
    """Return the review-only contract for a future external updater helper.

    This does not launch a helper, install an update, replace files, or relaunch
    Deimos. It documents the exact helper interface that must be implemented and
    validated before install behavior can be added.
    """
    return {
        "review_only": True,
        "helper_enabled": False,
        "spec_version": HELPER_SPEC_VERSION,
        "helper_executable_name": INSTALL_HELPER_NAME,
        "manifest_name": HELPER_MANIFEST_NAME,
        "log_name": HELPER_LOG_NAME,
        "rollback_dir_name": HELPER_ROLLBACK_DIR_NAME,
        "required_cli_args": [
            "--manifest <path-to-deimos-helper-manifest.json>",
            "--wait-pid <current-deimos-process-id>",
            "--log <path-to-deimos-updater-helper.log>",
        ],
        "optional_cli_args": [
            "--relaunch <path-to-current-Deimos.exe>",
            "--dry-run",
            "--timeout-seconds <seconds>",
        ],
        "manifest_required_fields": [
            "schema_version",
            "release_tag",
            "target_executable",
            "staged_executable",
            "expected_sha256",
            "rollback_directory",
            "install_log",
            "created_at_utc",
            "user_confirmed",
        ],
        "exit_codes": HELPER_ALLOWED_EXIT_CODES,
        "required_helper_safety_rules": [
            "validate manifest schema before touching any executable",
            "wait for current Deimos process to exit before replacement",
            "verify staged executable SHA-256 before backup",
            "create rollback backup before replacement",
            "replace target executable only after backup succeeds",
            "verify target executable SHA-256 after replacement",
            "restore rollback backup if post-replacement verification fails",
            "write a structured install log for every attempt",
            "never delete staged files or rollback backup during the same transaction",
            "relaunch only when explicitly requested in CLI arguments",
        ],
        "forbidden_helper_behaviors": [
            "network downloads",
            "release selection",
            "silent install without user_confirmed true",
            "deleting rollback backups during install",
            "modifying files outside target executable, backup path, and log path",
        ],
    }


def build_update_helper_manifest(
    release: ReleaseInfo | None,
    staged_paths: dict[str, Path | str],
    target_executable: Path | str,
    rollback_directory: Path | str,
    install_log: Path | str,
    user_confirmed: bool = False,
    created_at_utc: str | None = None,
) -> dict[str, Any]:
    """Build a future-helper manifest without enabling helper execution."""
    staged_review = build_staged_asset_review(release, staged_paths)
    expected_sha256 = staged_review.get("expected_sha256")
    return {
        "schema_version": HELPER_SPEC_VERSION,
        "review_only": True,
        "helper_enabled": False,
        "release_tag": release.tag_name if release else None,
        "target_executable": str(target_executable),
        "staged_executable": str(Path(staged_paths.get(STABLE_EXE_ASSET, ""))) if staged_paths else "",
        "checksum_file": str(Path(staged_paths.get(STABLE_CHECKSUM_ASSET, ""))) if staged_paths else "",
        "expected_sha256": expected_sha256,
        "rollback_directory": str(rollback_directory),
        "install_log": str(install_log),
        "created_at_utc": created_at_utc,
        "user_confirmed": bool(user_confirmed),
        "install_locked": True,
        "staged_asset_review": staged_review,
        "helper_contract": build_update_helper_contract(),
    }


def validate_update_helper_manifest(manifest: dict[str, Any]) -> tuple[str, ...]:
    """Return manifest blockers for the future helper contract."""
    blockers: list[str] = []
    if not isinstance(manifest, dict):
        return ("manifest must be a JSON object",)
    required = build_update_helper_contract()["manifest_required_fields"]
    for field in required:
        if field not in manifest:
            blockers.append(f"manifest missing required field: {field}")
    if manifest.get("schema_version") != HELPER_SPEC_VERSION:
        blockers.append(f"manifest schema_version must be {HELPER_SPEC_VERSION}")
    if manifest.get("helper_enabled") is not False:
        blockers.append("helper_enabled must remain false until install implementation phase")
    if manifest.get("install_locked") is not True:
        blockers.append("install_locked must remain true during helper-spec phase")
    expected = manifest.get("expected_sha256")
    if expected is not None and not re.match(r"^[a-fA-F0-9]{64}$", str(expected)):
        blockers.append("expected_sha256 must be a 64-character hex string when present")
    if not manifest.get("target_executable"):
        blockers.append("target_executable must be set")
    if not manifest.get("staged_executable"):
        blockers.append("staged_executable must be set")
    if manifest.get("user_confirmed") is not True:
        blockers.append("user_confirmed must be true before a future helper may be launched")
    return tuple(blockers)

# PHASE44_HELPER_ARTIFACT_REVIEW
HELPER_EXECUTABLE_NAME = "deimos-updater-helper.exe"
HELPER_RELEASE_ASSET_NAME = "deimos-updater-helper.exe"
HELPER_RELEASE_CHECKSUM_ASSET_NAME = "deimos-updater-helper.exe.sha256"
HELPER_RELEASE_MANIFEST_FIELD = "updater_helper"

@dataclass(frozen=True)
class HelperArtifactReview:
    """Review-only status for a built updater helper artifact.

    This is intentionally not an install launcher. It only records whether a helper
    artifact exists, its size/hash, and whether the checksum file matches the
    stable release-artifact contract.
    """
    executable_path: str
    exists: bool
    size: int | None
    sha256: str | None
    checksum_path: str | None
    checksum_matches: bool | None
    install_locked: bool = True


def sha256_file(path: Path) -> str:
    hasher = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def parse_sha256_checksum_file(path: Path) -> tuple[str, str | None]:
    text = Path(path).read_text(encoding="utf-8").strip()
    parts = text.split()
    if not parts or not re.fullmatch(r"[0-9a-fA-F]{64}", parts[0]):
        raise UpdateSystemError(f"Invalid SHA-256 checksum file: {path}")
    return parts[0].lower(), (parts[1] if len(parts) > 1 else None)


def review_helper_artifact(helper_path: str | Path, checksum_path: str | Path | None = None) -> HelperArtifactReview:
    helper = Path(helper_path)
    checksum = Path(checksum_path) if checksum_path else helper.with_suffix(helper.suffix + ".sha256")
    if not helper.exists():
        return HelperArtifactReview(str(helper), False, None, None, str(checksum), None)
    digest = sha256_file(helper)
    matches = None
    if checksum.exists():
        expected, filename = parse_sha256_checksum_file(checksum)
        matches = expected == digest and (filename in (None, helper.name, HELPER_EXECUTABLE_NAME))
    return HelperArtifactReview(str(helper), True, helper.stat().st_size, digest, str(checksum), matches)
