# Phase 27 GUI Bot Validation Patch Plan

## Static readiness
- tab_actions_build_bot_tab: true
- execute_bot_command_exists: true
- locale_en_exists: true
- locale_zh_exists: true
- command_parser_exists: true
- deimoslang_package_exists: true

## Recommended patch sequence
1. Add a pure static validator helper for bot text. Prefer a small module such as `src/gui/bot_validation.py` or a local helper in `src/gui/tab_actions.py`.
2. In `build_bot_tab`, call the validator inside `run_bot_callback` before queuing `GUICommandType.ExecuteBot`.
3. Blocking parser errors should prevent execution. Warnings should show a localized confirmation prompt.
4. Add localized keys to `locale/en.lang` and `locale/zh.lang` at the same time.
5. Do not change the `ExecuteBot` payload shape unless backend command handling is updated and reviewed.
6. Run parser-aware validation, locale checks, and command-surface reports after the patch.

## Minimum commands to run after patch
- `python .codex/scripts/deimos_parser_aware_bot_validator.py . .codex/reports/parser_aware_bot_validation.json`
- `python .codex/scripts/deimos_gui_validation_message_contract.py . .codex/reports/gui_validation_messages.json`
- `python .codex/scripts/deimos_gui_command_surface_guardrail.py . .codex/reports/gui_command_surface.json`
- `python .codex/scripts/deimos_gui_bot_editor_integration_report.py . .codex/reports/gui_bot_editor_integration.json`

## Hard blockers
- Do not execute bot text during validation.
- Do not reject legacy scripts because Wizard101 knowledge coverage is incomplete.
- Do not add English-only GUI text.
- Do not route invalid bot scripts into the backend execution path.
